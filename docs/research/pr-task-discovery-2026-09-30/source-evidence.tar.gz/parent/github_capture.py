import argparse
import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import subprocess


def capture(endpoint, destination, paginate=False):
    command = ["gh", "api", endpoint]
    if paginate:
        command += ["--paginate", "--slurp"]
    result = subprocess.run(command, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode().strip())
    json.loads(result.stdout)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(result.stdout)
    return {
        "endpoint": endpoint,
        "path": str(destination),
        "sha256": hashlib.sha256(result.stdout).hexdigest(),
        "paginated": paginate,
        "retrieved_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }


parser = argparse.ArgumentParser()
parser.add_argument("repo")
parser.add_argument("pr", type=int)
parser.add_argument("output", type=pathlib.Path)
args = parser.parse_args()
prefix = f"repos/{args.repo}"
routes = {
    "pr": (f"{prefix}/pulls/{args.pr}", False),
    "commits": (f"{prefix}/pulls/{args.pr}/commits?per_page=100", True),
    "files": (f"{prefix}/pulls/{args.pr}/files?per_page=100", True),
    "reviews": (f"{prefix}/pulls/{args.pr}/reviews?per_page=100", True),
    "review-comments": (f"{prefix}/pulls/{args.pr}/comments?per_page=100", True),
    "issue-comments": (f"{prefix}/issues/{args.pr}/comments?per_page=100", True),
}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
    futures = {
        name: executor.submit(capture, endpoint, args.output / f"{name}.json", paginated)
        for name, (endpoint, paginated) in routes.items()
    }
    receipt = [future.result() for future in futures.values()]
(args.output / "capture.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"repo": args.repo, "pr": args.pr, "output": str(args.output), "endpoints": len(receipt)}))
