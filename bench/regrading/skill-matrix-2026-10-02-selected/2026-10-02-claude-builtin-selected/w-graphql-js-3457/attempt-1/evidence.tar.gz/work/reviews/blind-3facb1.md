# Review blind-3facb1

### Item 1
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:591
Claim: Argument comparison now always builds, sorts and prints a synthetic ObjectValueNode for both fields, with no fast path. The old code returned early on a length mismatch or when both lists were empty.
Consequence: findConflict runs for every pair of same-response-name fields, and this validator is performance-critical (it memoizes pairs for that reason). Each call now allocates an ObjectValue plus ObjectField nodes, copies and sorts the fields, and runs the full print() visitor twice. This happens even for the common case of no arguments, where both sides just print '{}', and for pairs with different argument counts. Large queries with many repeated fields therefore do much more allocation and string work than before. A cheap `args1.length !== args2.length` check, or skipping when both lists are empty, would keep the fast path.
Fix: —

### Item 2
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637
Claim: Top-level arguments are now compared by sorting them as object fields with naturalCompare. The old code matched arguments by name, so this is a semantic change.
Consequence: Argument order is now handled by naturalCompare, which treats digit runs as numbers, instead of by exact name equality. Sorting is stable, so any two distinct names that naturalCompare considers equal keep their source order, and the same arguments written in a different order print differently. That would produce a false 'differing arguments' conflict where the old name-based lookup reported none. I did not find such a pair of names, because the digit loop appears to separate cases like 'a1' and 'a01'. Duplicate argument names, which are invalid but reach this rule when it runs alone, are also handled differently. The old code matched each argument to the first same-named argument on the other side, while the new code compares the whole sorted sequence, so `f(a:1,a:2)` against `f(a:2,a:1)` is now a conflict.
Fix: —

### Item 3
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:638
Claim: The FIXME and the `/* c8 ignore next */` for the possibly-undefined `arguments` were moved into the helper without resolving the underlying issue (#2203). The nullish fallback stays untested.
Consequence: FieldNode.arguments is optional in the AST type, and hand-built ASTs may omit it. The `?? []` fallback is still excluded from coverage, so a regression there would not be caught. The ignore comment now sits on a different statement than before, so any coverage tooling keyed to the old line will not see it. This is minor.
Fix: —

### Item 4
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637
Claim: Wrapping arguments in a fake ObjectValueNode to reuse print and sortValueNode is a hack that compares printed strings. It also drops the name-keyed semantics that sameArguments made explicit.
Consequence: The synthetic node has no `loc`, and the code relies on the printer's `{...}` formatting and on sortValueNode handling only objects and lists. A future change to the printer or to sortValueNode silently changes validation behavior. A dedicated comparison of sorted argument name/value pairs would be less fragile, because the comparison would not depend on how the printer formats ObjectValue.
Fix: —
