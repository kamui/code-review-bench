# Review blind-cd336d

### Item 1
Location: internal/pretty/pretty.go:40-41
Claim: In `internal/pretty/pretty.go:39–61`, the migration makes both protobuf branches use
`protojson.MarshalOptions` with the same effective indentation, but retains two copies of
marshaling, error fallback, and the Any-resolution explanation. The explicit `Multiline: true` in
the second branch creates no policy difference: protobuf v1.32.0 treats a nonempty `Indent` as
multiline. Normalize v1 inputs with `protoadapt.MessageV2Of` at the input boundary and render all
protobuf messages through one branch. This deletes an entire duplicate rendering path and removes
the remaining dependency on the old `proto` package from this helper while preserving the ordinary
JSON fallback. Verification is static against the pinned protobuf implementation; the worked
replacement and nil-handling considerations are in
[04_pretty_and_migration.md](04_pretty_and_migration.md).
Consequence: —
Fix: —

### Item 2
Location: encoding/proto/proto.go:27
Claim: In `encoding/proto/proto.go:27`, changing the imported `proto` package rebinds the existing
assertions in `Marshal` and `Unmarshal` to the v2 interface, which requires `ProtoReflect`. A
message implementing the legacy `Reset`, `String`, and `ProtoMessage` methods now fails both
operations, although the same message works with the base codec. This changes the accepted RPC
payload contract during an import migration and makes existing clients or servers using old
generated messages fail before normal application handling. Normalize either message interface to v2
using the canonical `protoadapt` conversions, share that normalization between the two codec
methods, and retain the existing rejection of unrelated inputs. The overlay reproduction fails both
operations at head and passes against the base implementation;
[01_codec_and_binarylog.md](01_codec_and_binarylog.md) contains the evidence and worked boundary
design.
Consequence: —
Fix: —

### Item 3
Location: internal/binarylog/method_logger.go:31
Claim: In `internal/binarylog/method_logger.go:31`, the new `proto` import also narrows the existing
assertions in `ClientMessage.toProto` and `ServerMessage.toProto`. A legacy protobuf message falls
into the unsupported-input branch and produces a normal message log entry with empty data and length
zero instead of its serialized payload. Both directions reproduce this loss at head, while the base
implementations record the expected eight bytes. Fix the logging boundary independently of the codec
so legacy messages remain loggable, including when an application uses a compatible custom codec.
Extract the repeated payload conversion into one local helper that accepts v1 messages, v2 messages,
and `[]byte`, using `protoadapt` for conversion and retaining the current logging behavior for
failures. [01_codec_and_binarylog.md](01_codec_and_binarylog.md) supplies the results and a concrete
simplification.
Consequence: —
Fix: —

### Item 4
Location: internal/status/status.go:158-163
Claim: In `internal/status/status.go:158–163`, `Details` appends the direct result of `Any.UnmarshalNew`,
although `WithDetails` explicitly continues to accept `protoadapt.MessageV1`. For a registered
legacy message, `WithDetails` succeeds but `Details()[0]` is now `*impl.messageIfaceWrapper` rather
than the original concrete message type; callers' type switches stop recognizing the detail, and
direct type assertions can panic. The old `ptypes.DynamicAny` path performed the conversion back to
v1. Append `protoadapt.MessageV1Of(detail)` after a successful decode so the compatibility wrapper
stays inside the status implementation. Add a registered legacy-only round-trip case and avoid using
direct v2 assertions to verify fixtures that are declared as v1 messages. The concrete-type
reproduction fails at head and passes with the base implementation; [02_status.md](02_status.md)
explains the adapter symmetry and testing gap.
Consequence: —
Fix: —

### Item 5
Location: balancer/rls/config.go:310
Claim: In `balancer/rls/config.go:310` and `xds/internal/xdsclient/transport/loadreport.go:173–177`,
replacing `ptypes.Duration` with `CheckValid` plus `AsDuration` removes rejection of values that are
valid protobuf durations but exceed Go's `time.Duration` range. A duration of 315576000000 seconds
now becomes 2562047h47m16.854775807s with no error; the base rejects it. RLS can consequently accept
an unrepresentable lookup timeout, and LRS can accept an interval that effectively stops periodic
reporting for centuries. Keep protobuf validity and Go representability as one checked conversion
contract, with nil-as-unset handled only by the RLS caller. A small conversion helper can validate,
convert, and compare `durationpb.New(converted)` with the original seconds and nanos to detect
saturation without hand-maintained integer-bound arithmetic. Positive and negative overflow
reproduce in RLS, and positive overflow reproduces in LRS; all pass against the base
implementations. [03_durations_and_lrs.md](03_durations_and_lrs.md) gives the evidence and worked
conversion.
Consequence: —
Fix: —

### Item 6
Location: xds/internal/xdsclient/transport/loadreport.go:174-175
Claim: In `xds/internal/xdsclient/transport/loadreport.go:174–175`, the condition discards the error
returned by `rInterval.CheckValid()` and formats the earlier `stream.Recv()` error instead. That
earlier error is necessarily nil on this path, so an interval with out-of-range nanos returns
`invalid load_reporting_interval: <nil>` and loses the reason the server response was rejected. Bind
the validation error in the conditional, or format the error returned by the checked duration
conversion proposed above. This preserves the diagnostic boundary and removes reliance on an
unrelated variable. The invalid-nanos reproduction fails at head and passes against the base
implementation; [03_durations_and_lrs.md](03_durations_and_lrs.md) records the exact result.
Consequence: —
Fix: —

### Item 7
Location: test/tools/go.mod:7
Claim: In `test/tools/go.mod:7`, why does switching `protoc-gen-go` also downgrade `golang.org/x/tools`
from v0.17.0 to v0.14.0? Please identify a requirement for the downgrade or retain the base version.
This is a scope question, not a demonstrated defect;
[04_pretty_and_migration.md](04_pretty_and_migration.md) records the manifest evidence and
verification limit.
Consequence: —
Fix: —
