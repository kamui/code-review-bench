# Review blind-0f442c

### Item 1
Location: encoding/proto/proto.go:40-54
Claim: In `encoding/proto/proto.go` lines 40-54 the bodies of `codec.Marshal` and `codec.Unmarshal` are unchanged, but the import under their `v.(proto.Message)` assertions moved from `github.com/golang/protobuf/proto` to `google.golang.org/protobuf/proto`, so the assertion now demands `ProtoReflect()` and any message that implements only `Reset`/`String`/`ProtoMessage` (output of `protoc-gen-go` before v1.4, gogo/protobuf, hand-written legacy types) fails with `failed to marshal, message is *T, want proto.Message`. This is the codec registered as `proto`, so every RPC on such a service breaks after upgrading. I confirmed it by execution: an overlay test with a V1-only message returns that error for both directions at head and round-trips correctly (`[10 1 110]`, then `"n"`) when only `proto.go` is swapped back to base. A pure import swap is the wrong shape for this file; the codec is the boundary where grpc-go accepts user message types and it needs to say what it accepts. The remedy is a small `messageV2Of(v any) proto.Message` that returns V2 messages as-is, adapts `protoadapt.MessageV1` through `protoadapt.MessageV2Of`, and returns nil otherwise, used by both methods, plus a test with a V1-only type. Full evidence and code are in `01_v1_message_boundary.md`.
Consequence: —
Fix: —

### Item 2
Location: internal/binarylog/method_logger.go:242-291
Claim: In `internal/binarylog/method_logger.go` lines 242-251 (`ClientMessage.toProto`) and 282-291 (`ServerMessage.toProto`) the same import swap narrowed `c.Message.(proto.Message)` to APIv2, so a V1-only message falls through to the final `else`, logs "message to log is neither proto.message nor []byte" at info level, and the emitted `GrpcLogEntry` carries `Length: 0` and no data. This is worse than finding 1 in one respect: nothing fails, the audit record is just empty. Confirmed by execution: head produces `len=0 data=[]` for both client and server entries, base `method_logger.go` produces `len=3 data=[10 1 110]`. The two blocks were already copy-pasted before this PR, the PR had to edit the file anyway, and it left both copies with the same defect. Collapse them into one `marshalPayload(msg any) []byte` that uses the same V1-to-V2 helper as the codec, so the two `toProto` methods differ only in their event type. While there, `timestamp := timestamppb.Now(); m.Timestamp = timestamp` at lines 92-93 is a leftover temporary from the old two-value call and should be one assignment. See `01_v1_message_boundary.md`.
Consequence: —
Fix: —

### Item 3
Location: internal/status/status.go:152-166
Claim: `internal/status/status.go` line 134 deliberately keeps the input typed as `...protoadapt.MessageV1` and adapts on line 141, which is correct and source-compatible. The output side at lines 152-166 was not given the same care: `any.UnmarshalNew()` returns an APIv2 message and it is appended as-is, whereas base went through `ptypes.DynamicAny`, which unwrapped legacy messages to their concrete Go type. Confirmed by execution: for a V1-only detail, head returns `*impl.messageIfaceWrapper` (a type from protobuf-go's internal package that does not implement APIv1 and that callers cannot name), base returns the caller's own `*legacyDetail`. User code that type-switches on `st.Details()` silently stops matching, and feeding a returned detail back into `WithDetails` panics on the type assertion. The contract is now V1 in, V2 out, undocumented. The fix is one call, `details = append(details, protoadapt.MessageV1Of(detail))`, which unwraps legacy wrappers and returns dual-API generated messages unchanged, with a doc sentence stating the round-trip guarantee and a V1-only case in `TestStatus_ErrorDetails`. The branch history has a commit titled "add compatibility test for status" but no such test survives in the tree. The double cast through a newly imported `protoreflect.ProtoMessage` at `status/status_test.go` line 359 is fallout from the same asymmetry and goes away with the fix. See `01_v1_message_boundary.md`.
Consequence: —
Fix: —

### Item 4
Location: xds/internal/xdsclient/transport/loadreport.go:173-177
Claim: In `xds/internal/xdsclient/transport/loadreport.go` lines 173-177 the old `interval, err := ptypes.Duration(...)` became `if rInterval.CheckValid() != nil { return nil, 0, fmt.Errorf("invalid load_reporting_interval: %v", err) }`. The result of `CheckValid()` is never bound; the `err` being formatted is the one from `stream.Recv()` on line 165, which is necessarily nil at that point because line 166 already returned otherwise. The error is therefore always the literal text `invalid load_reporting_interval: <nil>`, and it only compiles because a stale `err` happened to be in scope. Confirmed by reading, not executed. Write it as `if err := interval.CheckValid(); err != nil { ... }` and convert with `AsDuration()` at the single return on line 190, which also removes the `rInterval`/`interval` pair. The same validate-then-convert idiom was written a second, different way in `balancer/rls/config.go` lines 306-311 as `return d.AsDuration(), d.CheckValid()`, which returns a non-zero value alongside an error and quietly drops the old `time.Duration` overflow check; its callers happen to be safe, but both sites should use the same boring form. See `02_duration_and_error_call_sites.md`.
Consequence: —
Fix: —

### Item 5
Location: test/tools/go.mod:7
Claim: `test/tools/go.mod` line 7 at head pins `golang.org/x/tools v0.14.0`; base has v0.17.0, set by the base commit itself (`5051eeae grpc: Update go mod (#6939)`). `go.sum` moves `x/sync` from v0.6.0 to v0.4.0 and adds `x/sys v0.13.0` to match. None of this has anything to do with protobuf; the intended change in this module is swapping the `protoc-gen-go` tool import in `tools.go` and its `require` line. The head commit is "resolve conflicts and add changes", so this looks like the branch's stale file winning a conflict. It rolls back the `goimports` that `vet.sh` installs from this module and guarantees churn in the next dependency bump. Confirmed from the diff and file history; I could not build the tools module because `x/tools` is not in the provided module cache. Regenerate from `main`'s `go.mod` and `go.sum`, change only `tools.go`, and run `go mod tidy` in `test/tools`. See `03_build_and_migration_hygiene.md`.
Consequence: —
Fix: —

### Item 6
Location: internal/pretty/pretty.go:39-61
Claim: In `internal/pretty/pretty.go` lines 39-61 the `protov1.Message` case used to call `jsonpb.Marshaler` and now calls `protojson.MarshalOptions{Indent: jsonIndent}` on `protov1.MessageV2(ee)`; the `protov2.Message` case below it calls `protojson.MarshalOptions{Multiline: true, Indent: jsonIndent}` on `ee`. `protojson` documents that a non-empty `Indent` implies `Multiline`, so after this PR the two branches are the same code with the same duplicated fallback and comment, differing only in an adapter call. The file also still imports `github.com/golang/protobuf/proto` on line 27 just to name the V1 interface and its adapter, while the rest of the PR uses `protoadapt` for that. This is a refactor that changed the implementation without noticing it had removed the reason for the branch. Normalise to V2 once with the same helper proposed in finding 1 and keep a single proto branch; that deletes about ten lines, the import alias pair, and one of the remaining uses of the old module. See `01_v1_message_boundary.md`.
Consequence: —
Fix: —

### Item 7
Location: status/status_test.go:412
Claim: `status/status_test.go` line 412 replaces the expected value `errors.New(...)` with `protoimpl.X.NewError("invalid empty type URL")`, compared by `equalError` on `.Error()` text (lines 429-431). `runtime/protoimpl` is documented as "should only ever be imported by generated messages", and this is now the only hand-written file in the repository that imports it. The reason it is needed is that protobuf-go deliberately randomises the `proto:` prefix so callers do not compare error strings; the test defeats that safeguard by calling the library's private constructor and is still pinned to the exact wording inside `anypb`. `Details()` promises only that an undecodable detail is replaced by an error, so the test should assert that the first element is a non-nil `error` and stop there. That removes the import and stops the next protobuf-go release from breaking the test by rewording a message. See `02_duration_and_error_call_sites.md`.
Consequence: —
Fix: —

### Item 8
Location: vet.sh:152-157
Claim: After the PR, non-generated code still imports the old module in `channelz/service` (four files, `ptypes`), `xds/internal/xdsclient/bootstrap/bootstrap.go` line 473 (`jsonpb.Unmarshaler`), `internal/pretty/pretty.go`, `credentials/credentials.go` and the frozen `testv3.go`. The last two are legitimate (exported API typed on the old interface, and a deliberately frozen generated file). `pretty.go` and `bootstrap.go` are simply unfinished, and channelz was migrated and reverted twice on the branch with nothing in the tree explaining why. `go.mod` therefore still lists `github.com/golang/protobuf` as a direct requirement, and `vet.sh` is untouched: lines 152-157 still blanket-ignore every staticcheck deprecation hit mentioning `"github.com/golang/protobuf` or `: ptypes.`, and the only import guard at line 97 covers unaliased `ptypes/` sub-packages. Nothing prevents the next change from re-importing `github.com/golang/protobuf/proto` in any of the files just cleaned, and nothing records that the holdouts are a bounded list. Add an allow-listed `git grep` guard to `vet.sh` in the idiom the file already uses, finish `pretty.go` and `bootstrap.go` here, and either finish channelz or state in the PR that it is deferred. See `03_build_and_migration_hygiene.md`.
Consequence: —
Fix: —

### Item 9
Location: (no file)
Claim: Is dropping APIv1-only message support in the default codec and in binary logging intended? If it is, it is a breaking change for users of old generators and gogo/protobuf and needs to be stated in the PR and release notes rather than arriving as a side effect of an import rename; if it is not, findings 1 and 2 stand as written.
Consequence: —
Fix: —

### Item 10
Location: (no file)
Claim: Why was the channelz migration reverted twice on this branch, and is there a tracked follow-up? The answer decides whether `channelz/service` belongs on a permanent allow-list or a temporary one in finding 8.
Consequence: —
Fix: —
