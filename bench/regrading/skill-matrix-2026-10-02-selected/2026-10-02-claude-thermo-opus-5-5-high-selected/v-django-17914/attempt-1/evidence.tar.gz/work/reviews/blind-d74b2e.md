# Review blind-d74b2e

### Item 1
Location: django/db/backends/postgresql/base.py:369-383
Claim: `_configure_connection()` carries a comment saying it must not touch anything on `self` except variables, because the pool calls it on its own threads. Six lines later it passes `self.ops` to `ensure_role()`, which calls `ops.compose_sql()`, which is `mogrify(sql, params, self.connection)` with `self.connection` being the Django wrapper, and `mogrify` opens a Django cursor on it. On a pool worker thread that means `wrapper.cursor()` → `ensure_connection()` → `wrapper.connect()` → `pool.getconn()`, waiting for the very connection being configured, while the thread that owns the wrapper is itself blocked in `getconn()`. With a fake driver and otherwise real code, pooled connect succeeds in 0.0 s without `assume_role` and fails with `PoolTimeout` when it is set, with `wrapper.connect()` observed running on two pool worker threads. The only role test was moved to `no_pool_connection()` by this PR, so nothing covers the combination. The same bound-method registration also makes the pool hold a strong reference to whichever per-thread wrapper first touched `.pool` and run that wrapper's code on foreign threads for the life of the pool. The remedy is to compose the role statement against the raw connection that was passed in (`mogrify("SET ROLE %s", [role], connection)` works on a driver connection under both psycopg versions) and to hand the pool a callback closed over plain values rather than a bound wrapper method; add a pooled role test. Verified with a fake driver, not against a live server. Detail: `01_connection_configuration.md`.
Consequence: —
Fix: —

### Item 2
Location: django/db/backends/postgresql/base.py:202-241
Claim: `BaseDatabaseWrapper.connect()` recomputes `get_connection_params()` on every connect and passes the result to `get_new_connection(conn_params)`, but the pooled branch ignores the argument and uses a pool that froze an earlier snapshot of the same parameters under the alias. Django mutates `settings_dict` in place in `create_test_db()` (switching `NAME` to the test database), in `destroy_test_db()` when `keepdb` is set, and in `setup_worker_connection()`, and none of those invalidates the pool; the PR added `close_pool()` only to `_clone_test_db()`, `_destroy_test_db()` and `ensure_timezone()`. The stale state is directly observable: after a pool exists, changing `settings_dict["NAME"]` leaves `get_connection_params()["dbname"]` at the new value and `pool.kwargs["dbname"]` at the old one, and a `copy()` with a different `NAME` and `TIME_ZONE` on the same alias is handed the original's pool. If a pooled connection has been opened on an alias before the test database is set up, the pool keeps serving connections to the pre-test database afterwards. Correctness should not depend on every site that edits `settings_dict` remembering a PostgreSQL-specific call. Store a signature (connection parameters, time zone name, role, pool options) next to the pool and rebuild when the parameters passed to `get_new_connection()` no longer match; that makes the argument meaningful again and lets the three `NAME`-changing sites work without pool code. Stale pool verified offline; reachability inside Django's own runner is question Q1. Detail: `02_pool_lifecycle.md`.
Consequence: —
Fix: —

### Item 3
Location: django/db/backends/postgresql/base.py:243-246
Claim: `self.pool` is read eight times across five methods, and four of those methods only want to know whether the wrapper is pooled, yet every read can construct a `ConnectionPool`, import `psycopg_pool`, call `get_connection_params()` and raise `ImproperlyConfigured`. Measured consequences: `ensure_timezone()` on a wrapper that has never connected constructs a pool and immediately closes it, which happens for every initialised PostgreSQL connection each time a test overrides `TIME_ZONE` or `USE_TZ`; and `_close()` after `close_pool()` registers a brand-new pool purely because `if self.pool:` was evaluated while the connection is returned to the old one. `close_if_health_check_failed()` runs the same get-or-create path on every cursor. The registry is also unsynchronised: the comment justifies `setdefault()` for creation, but the membership test, the final lookup and `del` in `close_pool()` are separate operations, so a concurrent close produces `KeyError`. Split the concept in two: a pure `pool_options` property answering "is pooling configured", and a pool lookup that is called from exactly one place, `get_new_connection()`, under a lock; have `close_pool()` pop and close without constructing. Verified offline. Detail: `02_pool_lifecycle.md`.
Consequence: —
Fix: —

### Item 4
Location: django/db/backends/postgresql/base.py:362-367
Claim: `ensure_timezone()` is documented on the base class as setting the connection's time zone and reporting whether it changed. Its first statement is now `self.close_pool()`, a process-wide action that fails every other client of the alias with `PoolClosed`, and it exists because the `setting_changed` receiver is the method's only caller. That forces `_close()` to return the connection through `self.connection._pool.putconn(...)`, which the code's own comment calls "a workaround for tests"; `_pool` is a private attribute of psycopg's connection class. This is test-only behaviour embedded in two production methods plus a dependency on a driver internal. Record on the wrapper which pool the current connection was checked out of (`self._connection_pool = pool` at checkout, cleared in `_close()`); `_close()` then returns the connection to that pool with no private access, `init_connection_state()` and `close_if_health_check_failed()` test that attribute instead of calling the factory, and with F2's signature check `ensure_timezone()` reverts to its pre-PR body. Verified by reading and by the offline sketch. Detail: `02_pool_lifecycle.md`.
Consequence: —
Fix: —

### Item 5
Location: django/db/backends/base/base.py:274-277
Claim: `BaseDatabaseWrapper.ensure_connection()` now raises `ProgrammingError("Cannot open a new connection in an atomic block.")` when `connection is None` and `closed_in_transaction` are both true. For every other backend that state is unreachable: base `close()` deliberately keeps the driver handle when closing inside `atomic()`, and only the pooled PostgreSQL `_close()` nulls `self.connection` itself. So a feature-specific condition was added to a shared path, the base class now has two mechanisms for one invariant with nothing explaining when each applies, and two more guards were needed in the PostgreSQL wrapper (`is_usable()` and `init_connection_state()` both gain a `connection is None` check). Either override `ensure_connection()` in the PostgreSQL wrapper so the guard lives beside the code that creates the state and `base/base.py` stays untouched, or make it a stated contract of `_close()` in the base class and test it on every backend. In both cases the test should run the real sequence (pooled connection, `atomic()`, `close()`, query) rather than assigning the two flags by hand. Verified by reading every assignment to the two attributes. Detail: `03_base_wrapper_and_settings_validation.md`.
Consequence: —
Fix: —

### Item 6
Location: django/db/backends/postgresql/base.py:89-104
Claim: The two setter bodies were moved to module-level `ensure_timezone(connection, ops, timezone_name)` and `ensure_role(connection, ops, role_name)`. The `ops` parameter is a back-pointer to the wrapper, so the functions are not actually wrapper-free (that is the mechanism behind F1). Meanwhile the `ensure_role()` method is gone and `init_connection_state()` no longer dispatches through `self.ensure_timezone()`, so a backend subclassing the PostgreSQL wrapper that overrides either hook silently loses its override, and the module now has a function and a method both named `ensure_timezone` that do different things. This moves complexity without deleting any. Keep both as methods parameterised by the connection they act on (`_configure_timezone(connection)`, `_configure_role(connection)`), keep `ensure_timezone()` and `ensure_role()` as one-line callers that pass `self.connection`, and delete the module functions. Verified by reading. Detail: `01_connection_configuration.md`.
Consequence: —
Fix: —

### Item 7
Location: django/db/backends/postgresql/base.py:209-222
Claim: The psycopg 2 check sits in `get_connection_params()`, a parameter builder, between two unrelated `pop()` calls; the `CONN_MAX_AGE` check, the `psycopg_pool` import check and the `True` → `{}` normalisation sit inside the lazy `pool` property and therefore fire from whichever method first reads it, including `_destroy_test_db()` and a signal receiver; and option keys that collide with Django's own keywords (`check`, `kwargs`, `open`, `configure`) are not checked at all and surface as a bare `TypeError` from `ConnectionPool()`. `BaseDatabaseWrapper.check_settings()` is the canonical hook for invalid configuration and is the first call in `connect()`. Override it once in the PostgreSQL wrapper so that all of these checks live together, leave `get_connection_params()` with a plain `pop("pool", None)`, and read `CONN_MAX_AGE` by index like the neighbouring `CONN_HEALTH_CHECKS` since both keys are always populated. Verified by reading; the `TypeError` was reproduced for three of the four keys. Detail: `03_base_wrapper_and_settings_validation.md`.
Consequence: —
Fix: —

### Item 8
Location: docs/ref/databases.txt:270-271
Claim: The new documentation states that the `pool` option "is ignored with ``psycopg2``", but `get_connection_params()` raises `ImproperlyConfigured("Database pooling requires psycopg >= 3")`, and the test asserting the raise is named `test_connect_pool_setting_ignored_for_psycopg2`. Raising is the better behaviour, so correct the sentence and rename the test. The same section should also say that `CONN_MAX_AGE` must be `0`, which is a hard error at runtime and the first thing someone moving from persistent connections will hit. Verified by reading. Detail: `03_base_wrapper_and_settings_validation.md`.
Consequence: —
Fix: —

### Item 9
Location: tests/backends/postgresql/tests.py:24-30
Claim: `no_pool_connection()` exists, in its own words, because "we cannot easily change the pool connections", and the PR substitutes it for `connection.copy()` in eleven pre-existing tests, so isolation level, role, cursor factory, server-side binding and client encoding are all untested with a pool; for the role that hides F1. The helper deep-copies settings that `copy()` has already deep-copied, and the seven new pool tests call a function named "no pool" and then turn pooling on. `test_pooling_health_checks` asserts on the private `pool._check`, `test_cannot_open_new_connection_in_atomic_block` never involves the pool and sets the flags by hand, `test_connect_pool` creates its pool before entering the `try` that cleans it up, and four of the seven new tests need `try/finally: close_pool()` because the registry outlives the wrapper. Once pools are selected by what they were built from (F2), a `copy()` with different options gets a correct pool, the helper can be deleted, the eleven tests revert, and `addCleanup(new_connection.close_pool)` replaces the boilerplate. Add tests for a pooled role, a pooled non-default isolation level, a pooled close inside `atomic()`, and a `NAME` change after a pool exists. Verified by reading; the tests could not be run. Detail: `04_tests.md`.
Consequence: —
Fix: —

### Item 10
Location: (no file)
Claim: Is there any path in Django's own runner, or in a typical project, that opens a pooled connection on an alias before `create_test_db()` switches `NAME`, or in a forked parallel worker before `setup_worker_connection()` does? `connection.features.is_postgresql_15` evaluated during discovery would do it through `temporary_connection()`. If so, are the tests then running against the pre-test database?
Consequence: —
Fix: —

### Item 11
Location: (no file)
Claim: If the intent is that any backend's `_close()` may release its handle itself, where should that be documented and tested? If not, is there an objection to moving the guard into the PostgreSQL wrapper?
Consequence: —
Fix: —
