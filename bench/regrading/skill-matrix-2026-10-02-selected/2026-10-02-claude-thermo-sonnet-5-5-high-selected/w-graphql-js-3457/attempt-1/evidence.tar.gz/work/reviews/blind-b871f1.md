# Review blind-b871f1

### Item 1
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:591-650
Claim: **Finding 1 (low): the cheap early exit is gone, and the canonical string is rebuilt for every pair.** In `OverlappingFieldsCanBeMergedRule.ts` the call at line 591 now runs `stringifyArguments(node1) !== stringifyArguments(node2)`, and the helper at lines 637-650 allocates an object node, copies and sorts its fields, and prints it, even when both fields have no arguments. The previous code returned immediately on differing argument counts and did no printing for empty argument lists. `findConflict` runs once per candidate pair, and a response name with n fields is compared O(n²) times, so each node is re-stringified many times. This is unlikely to matter on typical queries, but it is the hot path of an already quadratic rule and the rewrite removed its only fast exit. Keep a trivial length or empty check ahead of the stringify, or memoize the string per `FieldNode` in a `WeakMap`. The first option adds no state. This was confirmed by reading and not benchmarked. Full evidence is in `01_overlapping-fields-rule.md`.
Consequence: —
Fix: —

### Item 2
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637-650
Claim: **Finding 2 (low): the argument list is wrapped in a fabricated `ObjectValueNode` to reuse `sortValueNode`, with no comment explaining why.** The helper at lines 637-650 builds a loc-less object node from re-wrapped `ArgumentNode`s, relying on the argument and object-field shapes matching and on name-sorted printing being the canonical form. The `FIXME #2203` and `c8 ignore` for optional `arguments` also moved into this helper, away from the comparison they affect. The trade is acceptable and I would not block on it. Add a brief comment saying the wrapper exists to get sorted canonical output, or, if the pattern is wanted elsewhere, put a small argument-canonicalization helper beside `sortValueNode`. Details are in `01_overlapping-fields-rule.md`.
Consequence: —
Fix: —
