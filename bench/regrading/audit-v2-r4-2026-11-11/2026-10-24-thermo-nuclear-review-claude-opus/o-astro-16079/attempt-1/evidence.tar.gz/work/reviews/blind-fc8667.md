# Review blind-fc8667

### Item 1
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:21-26
Claim: ### 1. [High] A client-supplied `x-vercel-isr: 1` header brings back the untrusted `x_astro_path` path override that #15959 removed

**File:** `packages/integrations/vercel/src/serverless/entrypoint.ts`, lines 21–26 (the new `else if (request.headers.get('x-vercel-isr') === '1')` branch at lines 24–25).

**Evidence traced.**
- Commit `335a20416` (#15959, "Require trusted secret for path overrides") changed the handler so the path override is applied only when the request carries the random per-build `middlewareSecret` (`crypto.randomUUID()`, `src/index.ts:261`). Before that change, `x_astro_path` from the query string was trusted unconditionally. The test `test/path-override-security.test.js` ("ignores untrusted x_astro_path query param on _render") pins that behaviour.
- This PR adds a second way to get the override. If the secret is missing but the request header `x-vercel-isr` equals `'1'`, the handler sets `realPath = url.searchParams.get(ASTRO_PATH_PARAM)` and rewrites `url.pathname` to it before `app.match(request)`. The only thing gating this is a plain request header. It is not signed and not secret, and nothing in the adapter sets it or checks where it came from: `grep` finds `x-vercel-isr` only on this one line. Any HTTP client can send it.
- The same entrypoint is bundled into both the `_render` and `_isr` functions. `buildISRFolder` calls `buildServerlessFolder(entry, …)` with the same `entryFile` (`src/index.ts:474`, `702–703`), and the non-ISR path builds `_render` from it too. So the bypass is not limited to ISR invocations. It applies to every `_render` route: all on-demand routes when `isr` is off, ISR-excluded routes, `/_image`, `/_server-islands/*`, and requests that edge middleware forwards to `_render`. For ISR deployments it also applies to `_isr`.
- **Reproduced in-process.** I built the `serverless-with-dynamic-routes` fixture (via `node --test test/path-override-security.test.js`, which passes) and called the built `_render.func` handler from a scratch script:
  - `GET https://example.com/api/public?x_astro_path=/api/private` with no extra header returns `{"id":"public"}`. This is the protection from #15959.
  - The same request with header `x-vercel-isr: 1` returns `{"id":"private"}`. The override is applied.

**Failure / vulnerability.** #15959 was meant to stop attackers from requesting one URL while getting a different route rendered. That defeats path-based controls that sit in front of the function: Vercel firewall/WAF path rules, path-scoped protection or rewrites in `vercel.json`, and CDN rules keyed on the visible path. With this change, an attacker requests an allowed path such as `/public?x_astro_path=/admin` with `x-vercel-isr: 1`, and the function renders `/admin`. In effect the security fix is reverted for anyone who knows to add one header. The PR body describes the change as a 404 bug fix and says nothing about the security trade-off. The existing security test does not cover the header, so it keeps passing and hides the regression.

I could not check whether Vercel's edge removes or overwrites a client-sent `x-vercel-isr` header before invoking functions; the platform is not available in this environment. Nothing in the adapter relies on or documents such stripping, and the header is not part of Vercel's documented Build Output API contract. Whatever the platform does, the adapter's own trust check is just "a header has a particular value". At minimum the branch should be limited to the `_isr` function and not run in `_render`. A trust signal the client cannot forge would be better. For example, the build could embed the secret in the ISR route `dest` query (`/_isr?x_astro_path=$0&…`) and check it, with care for `allowQuery`/cache keys, or the entrypoint could be built per function so `_render` never reads the query param.
Consequence: —
Fix: —

### Item 2
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:21-26
Claim: ### 2. [Low] No regression test for the ISR rewrite or for the new header trust boundary

**File:** `packages/integrations/vercel/src/serverless/entrypoint.ts`, lines 21–26. The PR adds no test files.

**Evidence traced.** The PR body says no tests were added. `test/isr.test.js` only checks the generated `prerender-config.json` and `config.json` routes. It never calls the built `_isr` handler, which is how the 404 regression from #15959 got in unnoticed. `test/path-override-security.test.js` does not send `x-vercel-isr`, so it misses Finding 1.

**Failure.** Neither behaviour has a test: that ISR requests render the rewritten path, and that a forged header on `_render` does not override the path. Either one can regress again silently. That is how both the original 404 and the security regression in Finding 1 went undetected.
Consequence: —
Fix: —
