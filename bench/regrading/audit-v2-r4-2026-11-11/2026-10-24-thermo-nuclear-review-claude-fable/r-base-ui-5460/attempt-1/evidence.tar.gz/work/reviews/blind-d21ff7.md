# Review blind-d21ff7

### Item 1
Location: packages/react/src/field/control/FieldControl.tsx:83-146
Claim: ### Finding 1 — Medium — `packages/react/src/field/control/FieldControl.tsx` lines 83–84 and 142–146: a native checkbox or radio rendered through `Field.Control` with a `value` attribute no longer updates field state or revalidates when toggled

**Evidence.** `isControlled` is computed as `valueProp !== undefined` (line 83). For `<input type="checkbox">` and `<input type="radio">` the `value` attribute is the submission value, not a controlled text value; React controls those inputs through `checked`, and `value` stays constant across toggles. With the PR, the `onChange` handler returns at line 144–146 before `setDirty`, `setFilled`, `clearErrors` and `validation.change`, because `isControlled` is true. The prop path at lines 105–115 never fires either, because `serializedValue` ("yes") never changes. So nothing in the field reacts to the toggle.

On the base branch the same markup ran the DOM path: `validation.change("yes")` on every toggle, which in the `onSubmit` revalidation path (`useFieldValidation.commit` with `revalidate = true`) reads `element.validity.valueMissing` and publishes all-valid once the box is checked.

Reproduced with a scratch test (jsdom, same markup on both branches):

```tsx
<Form>
  <Field.Root name="terms">
    <Field.Control type="checkbox" value="yes" required />
    <Field.Error match="valueMissing">Required</Field.Error>
  </Field.Root>
  <button type="submit">go</button>
</Form>
```

Submit with the box unchecked, then click the box:

| | base (`main`) | head (`review-head`) |
| --- | --- | --- |
| "Required" error still shown after checking | no | **yes** |
| `aria-invalid` on the checkbox after checking | removed | **still `"true"`** |

With `validationMode="onChange"` and a custom `validate`, base called `validate` on every toggle; head never calls it. The same markup without the `value` attribute behaves identically on both branches, which isolates the cause to the `isControlled` early return.

**Failure.** Any consumer using `Field.Control` / `Input` as a native checkbox or radio with a submission `value` (a very common HTML pattern, e.g. a terms-of-service checkbox with `value="yes"`) gets a stuck "Required" error and `aria-invalid="true"` after a failed submit even once the user satisfies the constraint, and onChange-mode validation stops responding to the control. This is a regression introduced by the diff, not pre-existing. The guard should distinguish "the `value` prop controls the text value" from "`value` is a constant submission value" (for example, treat `type="checkbox"` / `type="radio"` as not value-controlled, or keep the DOM path for inputs whose `value` did not change in response to the event).
Consequence: —
Fix: —

### Item 2
Location: packages/react/src/field/control/FieldControl.tsx:105-115
Claim: ### Finding 2 — Low — `packages/react/src/field/control/FieldControl.tsx` lines 105–115: the pull request body describes a different implementation and misstates the `clearErrors` behaviour

**Evidence.** The body says the guard against double validation is a `processedValueRef` that "records the value the change handler just handled"; the diff has no such ref, and instead skips the DOM path entirely when controlled (lines 142–146). The body says "A control that unmounts or becomes disabled while focused no longer latches `data-focused`"; there is no change to the focus handling anywhere in the diff (the `autoFocus` effect at lines 119–123 is only moved). The body's open question says "The sibling controls also call `clearErrors(name)` when their value changes. This PR does not", but line 110 of the diff calls `clearErrors(name)` on every programmatic controlled change, matching the siblings.

**Failure.** The description is not a code defect, but it is the only statement of intent for a merged change and it is wrong on three points. In particular, the `clearErrors` behaviour it says is absent is present: a programmatic value change on a controlled `Field.Control` now removes a Form-level server error for that field. That is defensible (it matches Switch, Checkbox, etc.), but reviewers and release notes relying on the body will believe the opposite. The body should be corrected to match the merged code, and the `clearErrors` decision should be stated explicitly since it is a behaviour change for `Input`/`Field.Control` consumers that display server errors.
Consequence: —
Fix: —
