# Review blind-1b25be

### Item 1
Location: crates/core/flags/complete/rg.zsh:441
Claim: Sourcing before compinit still runs the completion body
Consequence: In a zsh startup where `compinit` has not defined `compdef`, the new branch invokes `_rg` while the generated file is being sourced. The completion body then reaches completion-only commands outside a completion context, so the newly documented dynamic-source method still errors for this initialization order. State the prerequisite or change the guard, and verify the documented startup sequence.
Fix: Document that `compinit` must be run before the dynamic-source line, or distinguish completion invocation from top-level sourcing without using the absence of `compdef` as a reason to invoke `_rg`.
