# Review blind-999ebd

### Item 1
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:591
Claim: Argument comparison now always allocates, sorts and prints a synthetic object for both fields on every pair, losing the old cheap paths for no-argument fields and differing argument counts.
Consequence: A query with thousands of same-response-name fields without arguments (the adversarial case this rule was just hardened against in #3442) performs O(n^2) findConflict calls; each now builds two ObjectValueNodes and runs two full print() visitor traversals to compare "{}" with "{}", where the old code did a length check and an `every` over an empty array. Validation time and GC pressure rise sharply on the hot path.
Fix: —

### Item 2
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637
Claim: stringifyArguments is recomputed for the same FieldNode on every pairwise comparison, with no memoisation.
Consequence: A field with arguments that appears N times under one response name is sorted and printed 2*(N-1) times across the pairwise comparisons; a per-node cache (e.g. a WeakMap<FieldNode, string>) or stringifying once per field before the pair loop would cut this to N prints.
Fix: —

### Item 3
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:591
Claim: Fields with duplicated argument names are now compared as a sorted multiset, which changes which documents get the "differing arguments" conflict compared with the old first-match-by-name lookup.
Consequence: `{ f(a: 1, a: 1, b: 2) f(a: 1, b: 2, b: 2) }`: the old code found a same-named match for every argument and reported no conflict; the new code prints "{a: 1, a: 1, b: 2}" vs "{a: 1, b: 2, b: 2}" and reports one. Likewise `f(a: 1, a: 2)` vs `f(a: 2, a: 1)` now depends on sort stability for equal names. Only reachable in documents already invalid under UniqueArgumentNamesRule, but this rule's output changes when run alone, and no test covers it.
Fix: —

### Item 4
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:641
Claim: Arguments are disguised as a fake ObjectValueNode/ObjectFieldNode tree solely to reuse sortValueNode and print, coupling argument equality to the printer's object-literal formatting.
Consequence: Maintenance cost: the synthetic nodes are not real AST (no loc, ArgumentNodes relabelled as OBJECT_FIELD), and equality now depends on the textual output of print for ObjectValue. A simpler, more direct form is to sort the arguments by name and compare name plus print(sortValueNode(value)) pairwise, or to add a structural value-equality helper, which avoids the fake nodes and the extra allocations.
Fix: —

### Item 5
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:639
Claim: The `?? []` fallback and its FIXME/c8-ignore workaround are carried into the new helper rather than resolved, so the dead branch now runs on every call.
Consequence: Parsed FieldNodes always have `arguments` set (possibly empty), so the fallback only matters for hand-built ASTs; the new helper keeps the coverage-ignored dead branch and then maps the empty array into a new object and prints it, instead of returning early for an empty or missing argument list.
Fix: —
