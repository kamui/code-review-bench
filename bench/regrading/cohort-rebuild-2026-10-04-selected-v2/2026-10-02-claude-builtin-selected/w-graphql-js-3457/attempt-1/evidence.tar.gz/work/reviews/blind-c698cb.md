# Review blind-c698cb

### Item 1
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:592
Claim: The cheap argument-count short-circuit was removed. Every field-pair comparison now builds and prints a synthetic ObjectValueNode for both fields, even when neither field has arguments or the counts differ.
Consequence: findConflict runs for every pair of same-response-name fields in a large query. The old sameArguments returned false at once on a length mismatch and did no printing when both lists were empty. The new code always allocates the wrapper nodes, sorts, and calls print twice per pair, so validation of large overlapping selection sets does more work. A fast path is cheap to add: skip the comparison when both argument lists are empty, or when their lengths differ.
Fix: —

### Item 2
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637
Claim: Arguments are now compared by printing a fake input-object node, which is a hack. It couples argument equality to print() and sortValueNode() output formatting. The old name-based lookup and the 'differing arguments' semantics are no longer explicit.
Consequence: Any future change to the printer's object formatting, or to sortValueNode's handling of duplicate or naturally-ordered names, silently changes validation behaviour. Duplicate argument names are an example: (a:1, a:2) and (a:2, a:1) compare unequal only because the sort is stable. The `kind: Kind.OBJECT_FIELD` and `kind: Kind.OBJECT` literals also build synthetic AST nodes with no `loc`, which is fragile if the printer ever starts to rely on `loc`.
Fix: —

### Item 3
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:638
Claim: The FIXME and `c8 ignore` for `node.arguments ?? []` now sit inside a helper that gets called for both nodes. The ignore comment is attached to a single expression, so the coverage-ignore intent is less clear.
Consequence: The `/* c8 ignore next */` annotation covers only the `?? []` line. A maintainer reading `stringifyArguments` cannot tell why `arguments` might be undefined, and it is still not covered by any test. The issue #2203 workaround is now hidden in a utility function instead of next to the field comparison.
Fix: —

### Item 4
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:638
Claim: The two argument lists are stringified on every comparison and never cached, even though the same FieldNode is compared many times (pairwise across fields and fragments).
Consequence: A field with N occurrences under the same response name is compared in O(N^2) pairs. Each pair re-sorts and re-prints both nodes' arguments. Memoizing the string per FieldNode (for example in a WeakMap or in the existing comparison caches) would make the work O(N).
Fix: —

### Item 5
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637
Claim: No test was added or changed for the behavioural difference in argument comparison. The refactor changes semantics for duplicate argument names, and a case with differing argument counts was previously guarded by an explicit length check.
Consequence: Old code treated fields with arguments (a:1, a:1) and (a:1, b:2) as equal, because every argument in the first list found the first 'a' in the second. The new code reports a conflict. This is arguably a fix, but the diff has no regression test and the validation test file was left untouched, so the intended behaviour is unpinned.
Fix: —
