# Review blind-b87c6b

### Item 1
Location: packages/react/src/field/control/FieldControl.tsx:139
Claim: For a controlled Field.Control, the early `return` in onChange discards both `details.cancel()` and `event.defaultPrevented`, so the 'cancel stops internal handling' fix only works for uncontrolled inputs.
Consequence: A controlled input calls `onValueChange={(v, d) => { d.cancel(); setValue(v); }}`, or a keydown handler calls preventDefault on the change. The onChange handler returns early. The parent still updates `value`, and the `useValueChanged` effect then runs `clearErrors`, `setDirty`, `setFilled` and `validation.change(serializedValue)` unconditionally. Validation fires and server errors are cleared even though the change was canceled or prevented. This is a regression for controlled inputs: previously `defaultPrevented` skipped validation and clearErrors. The new tests for cancel and prevented changes only cover uncontrolled inputs.
Fix: —

### Item 2
Location: packages/react/src/field/control/FieldControl.tsx:112
Claim: The PR description names fixes that are not in the diff: `processedValueRef`, and clearing `data-focused` when the control unmounts or becomes disabled while focused.
Consequence: A focused Field.Control is disabled, or unmounted and conditionally re-rendered. No blur fires, `setFocused(false)` is never called, and `data-focused` stays latched on Field.Root. No test covers this. The description also says the PR 'does not' call `clearErrors`, but `useValueChanged` calls `clearErrors(name)` for every controlled change, so the 'open question' is already decided in code. The description and the code disagree, and the behavior is untested.
Fix: —

### Item 3
Location: packages/react/src/field/control/FieldControl.tsx:104
Claim: Field state is synced from the `value` prop in a layout effect, not from the event. Programmatic changes on a disabled control, or changes made in the same commit as mount, still validate or compare against a stale baseline.
Consequence: When `value` changes while the control is disabled, `useValueChanged` still calls `validation.change` and `clearErrors`, so a disabled field gets validated and its errors cleared. If a parent sets the value in a mount-time effect, `validityData.initialValue` is still `null` in that commit (the baseline is captured by `setValidityData` in the registration effect). `setDirty` then compares against `''` instead of the real baseline, which can mark the field dirty incorrectly.
Fix: —

### Item 4
Location: packages/react/src/field/control/FieldControl.tsx:130
Claim: Dirty and filled state for controlled inputs now update one render late, in a layout effect after the parent re-renders. This causes an extra Field.Root render and a one-render window of stale state.
Consequence: On a controlled keystroke, onChange no longer calls `setDirty` or `setFilled`. The parent sets state and renders, then the effect calls `setDirty`, `setFilled` and `validation.change`, which schedules another Field.Root and context re-render. The first keystroke can therefore render an inconsistent intermediate state. The render-count test excludes the first keystroke, which hides this. The bundle-size and perf comments also show regressions.
Fix: —

### Item 5
Location: packages/react/src/field/control/FieldControl.tsx:101
Claim: The mount-time filled effect lost its `valueProp` dependency and its explicit `valueProp === ''` reset. Filled state now depends entirely on `useValueChanged`, which skips `null` or `undefined` values.
Consequence: A controlled `value` that changes to `null` or `undefined` is skipped by the `serializedValue === undefined` guard. The input is cleared, but `data-filled` and `data-dirty` stay stale. The same applies when the value toggles between controlled and uncontrolled.
Fix: —

### Item 6
Location: packages/react/src/field/control/FieldControl.tsx:87
Claim: The `serializedValue` registration only covers FieldControl. `String(value)` for non-primitive controlled values produces '[object Object]' or comma-joined strings.
Consequence: The PR claims arrays are fixed. With `value={['a','b']}` the serialized value is 'a,b', which collides with `['a,b']`, and an array mutated in place is never detected. The `useValueChanged` comparison of the serialized string is a lossy proxy for the value, and `serializedValue` is also what gets registered as the form value.
Fix: —

### Item 7
Location: packages/react/src/field/control/FieldControl.test.tsx:190
Claim: Test coverage is missing for the behaviors the description claims.
Consequence: No test covers: cancel or preventDefault on a controlled input (which would expose the regression above); a consumer that rejects or rewrites the value; a pending async validator being superseded by a programmatic change; resolved errors clearing after a programmatic reset; array values; unmount or disable while focused; or `clearErrors` behavior. The 'renders once per keystroke' test measures after the first keystroke only.
Fix: —
