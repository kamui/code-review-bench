# Review blind-218f2f

### Item 1
Location: src/error/__tests__/GraphQLError-test.js:58
Claim: Test 'creates new stack if original error has no stack' no longer exercises the no-stack branch
Consequence: The original plain object `{ message: 'original' }` had no `stack`, so the test hit the `else if (Error.captureStackTrace)` branch in GraphQLError.js. A real Error always has a stack, so the test now takes the `originalError.stack` branch and duplicates 'uses the stack of an original error'. The fallback path loses its only coverage while the test name still claims to cover it.
Fix: Keep a Flow-valid original error with no stack, e.g. `const original = new Error('original'); delete original.stack;` (or set stack to undefined via a cast to any), so the captureStackTrace / Error().stack fallback in GraphQLError.js is exercised again.
