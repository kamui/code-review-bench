# Review blind-5dce69

### Item 1
Location: xds/internal/xdsclient/transport/loadreport.go:173-177
Claim: **1. Error is dropped in the load-report interval validation (regression).** In `xds/internal/xdsclient/transport/loadreport.go:173-177`, the old `interval, err := ptypes.Duration(...)` was replaced by `rInterval.CheckValid() != nil` whose result is thrown away, and the error message still formats `err`, which at that point is the nil error from `stream.Recv()`. Callers will see "invalid load_reporting_interval: <nil>" and the real cause is lost. The fix is a scoped `if err := rInterval.CheckValid(); err != nil`. Details in `02_xds.md`, Finding C.
Consequence: —
Fix: —

### Item 2
Location: test/tools/go.mod:8
Claim: **2. `test/tools/go.mod` downgrades `golang.org/x/tools` from v0.17.0 to v0.14.0 (and x/sync to v0.4.0).** A protobuf-import PR has no reason to touch linter tool versions; this looks like a conflict-resolution or `go mod tidy` artifact. See `test/tools/go.mod:8` and the matching `go.sum` hunk. Restore the previous versions and keep only the intended edits. Details in `03_build-and-incomplete-migration.md`, Finding E.
Consequence: —
Fix: —

### Item 3
Location: internal/pretty/pretty.go:37-62
Claim: **3. `internal/pretty/pretty.go` now has two nearly identical marshalling branches.** The `protov1.Message` case (lines 39-47) and the `protov2.Message` case (lines 49-62) both build `protojson.MarshalOptions`, call `Marshal`, and fall back to `%+v` with the same comment; they differ only by `Multiline: true` and a `protov1.MessageV2` adapter call, and the v1 branch keeps the `golang/protobuf` import alive. Since every generated v2 message also satisfies the v1 interface, the second case is effectively unreachable. Collapse into one path using `protoadapt.MessageV2Of` and delete the v1 import. Also note that `jsonpb` output was stable while `protojson` output is deliberately unstable, so any exact-match consumer needs checking. See `01_core-library.md`, Finding A.
Consequence: —
Fix: —

### Item 4
Location: credentials/credentials.go:31
Claim: **4. The migration is incomplete while claiming to be repository-wide.** Non-generated code still imports `github.com/golang/protobuf` in `credentials/credentials.go:31`, `xds/internal/xdsclient/bootstrap/bootstrap.go:32` (jsonpb), `channelz/service/*.go` (ptypes, wrappers), `reflection/grpc_testing_not_regenerate/testv3.go`, and `internal/pretty/pretty.go:27`. The root `go.mod` still lists it as a direct requirement, while `examples/go.mod` was flipped to `// indirect`, so the modules now disagree. Finish the conversion (`jsonpb` to `protojson`, `ptypes.Duration` to `AsDuration`) or state the follow-up. See `03_build-and-incomplete-migration.md`, Finding F.
Consequence: —
Fix: —

### Item 5
Location: internal/status/status.go:134
Claim: **5. `Status.WithDetails` exposes `protoadapt.MessageV1` on the public API, and tests grow casts and an unstable hook.** `internal/status/status.go:134` changes the signature (public through the `status.Status` alias); it is source compatible only by alias coincidence. In `status/status_test.go:359` each element is cast to `protoreflect.ProtoMessage` on both sides of `proto.Equal`, and at line 412 the test depends on `protoimpl.X.NewError`, an explicitly unstable surface. Type the test table with v2 messages, adapt at the single `WithDetails` call site, and match errors without `protoimpl.X`. See `01_core-library.md`, Finding B.
Consequence: —
Fix: —

### Item 6
Location: xds/internal/xdsclient/xdsresource/unmarshal_lds.go:121-175
Claim: **6. Missed simplification in xDS Any handling.** `unmarshal_lds.go` (around lines 121-130 and 171-175) and similar sites translate `ptypes.Is` + `UnmarshalAny` into `MessageIs` + `UnmarshalTo`, keeping two allocations and two near-identical case bodies for the TypedStruct v1/v2 types. `Any.UnmarshalNew` with a type switch would delete the `MessageIs` calls. This is a follow-up level suggestion, not a blocker. See `02_xds.md`, Finding D.
Consequence: —
Fix: —

### Item 7
Location: examples/route_guide/server/server.go:36-43
Claim: **7. Import-group churn.** Several files lose blank-line grouping while moving imports (for example `examples/route_guide/server/server.go`, `balancer/grpclb/grpclb.go`). Cosmetic; see `03_build-and-incomplete-migration.md`, Finding G.
Consequence: —
Fix: —
