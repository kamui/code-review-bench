# Review blind-c01c2f

### Item 1
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:587-597
Claim: **1. The no-argument fast path was deleted, and the hot path now allocates and prints on every comparison.** In `findConflict` (`OverlappingFieldsCanBeMergedRule.ts`, around lines 590-597) the old `sameArguments` returned early on a length mismatch and, for two argument-less fields, did no work at all (`every` over an empty array). The new code unconditionally builds an `ObjectValueNode`, maps the arguments into `ObjectFieldNode`s, runs `sortValueNode` (which spreads and re-sorts), and calls `print` twice, once per field, even for the overwhelmingly common case of two fields with no arguments, where the answer is "equal" and trivially known. This rule is the validator's performance hot spot, and the file's own comments say fragment pairs are compared many times. The structure is still the right one. The remedy is a small guard that keeps the code simple: skip stringification when both argument lists are empty, or when only the lengths differ. If the author wants one flow with no special case, they should at least confirm with the existing validation benchmark (`resources/` / `benchmark/`) that the cost is not measurable. As written, the change trades an obviously cheap path for an unmeasured one. This is reasoned from the code and has not been benchmarked here.
Consequence: —
Fix: —

### Item 2
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637-650
Claim: **2. `stringifyArguments` fabricates a synthetic AST node to borrow a printer, and the trick is only implied by the variable name.** The helper builds a `{ kind: Kind.OBJECT, fields: ... }` literal with no `loc`, re-wraps each `ArgumentNode` as an `ObjectFieldNode`, and feeds it to `sortValueNode`. It works because `ArgumentNode` and `ObjectFieldNode` have the same `name`/`value` shape. That is clever but indirect, and the variable name `inputObjectWithArgs` does not say why an input object is being invented. A one-line comment ("arguments sort and print exactly like an input object's fields, so reuse that path") would make it a deliberate reuse rather than a magic trick. The more ambitious judo move is to teach the utilities layer about this: either a small `sortArguments`/`stringifyArguments` helper in `src/utilities` next to `sortValueNode`, or letting the rule compare the printed forms through one dedicated function there. That would keep AST-node fabrication out of a validation rule and give the sorter a single home for the "named things in a list" concept. Neither is a blocker.
Consequence: —
Fix: —

### Item 3
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637-650
Claim: **3. The FIXME and `c8 ignore` for `fieldNode.arguments ?? []` now live inside the helper, away from the comparison they were guarding, and are evaluated on each call.** The old code defaulted `args1`/`args2` once at the call site. The default now sits in a helper that is invoked twice per comparison, with the `/* c8 ignore next */` still attached to a line that coverage can no longer attribute to one particular call. Nothing is wrong behaviourally, but the open issue (#2203) is about `arguments` being optional on `FieldNode` in the type, and a reader has to find the helper to learn that. The remedy is to leave the pointer where it is and keep a note on the helper's contract: the helper takes a `FieldNode` and silently tolerates missing `arguments`, which is a "silent fallback papering over an unclear invariant" in the skill's terms. When #2203 is resolved, this `?? []` and its comment should be removed in the same change.
Consequence: —
Fix: —
