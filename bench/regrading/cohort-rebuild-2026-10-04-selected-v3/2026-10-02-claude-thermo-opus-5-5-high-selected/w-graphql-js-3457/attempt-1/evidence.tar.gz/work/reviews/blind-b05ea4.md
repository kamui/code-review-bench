# Review blind-b05ea4

### Item 1
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:591-650
Claim: `src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:591` and `:637-650`.

`findConflict` is called once for every pair of fields that share a response name, from the nested loops in `collectConflictsWithin` and `collectConflictsBetween`. At the base, the argument check in that loop was cheap when there was nothing to compare: `sameArguments` compared two lengths and ran `every` over an empty array. At the head, line 591 calls `stringifyArguments` on both nodes for every pair. Each call allocates a synthetic `ObjectValueNode`, maps the arguments into new `ObjectFieldNode` objects, copies and sorts them in `sortValueNode`, and then runs `print`, which is a full `visit` traversal with the printer reducer. For two fields with no arguments this work produces the string `{}` twice and compares them.

The cost is measured, not inferred. Validating a single selection set that repeats an argument-less field, with only this rule enabled, takes 60 ms at the base and 2832 ms at the head for 1000 repetitions, 17 ms against 710 ms for 500, and 5 ms against 173 ms for 250. That is a 30x to 47x slowdown on the path every query takes, since most fields have no arguments. For fields that do carry arguments the head is about 1.2x to 1.4x slower than the base (2167 ms against 2671 ms for 200 repetitions), because the base already paid for a print per argument value per pair.

This matters beyond throughput. The rule's cost is controlled by the document author, so a larger constant on the quadratic term directly lowers the size of query needed to hold a server's validation step for seconds. The preceding commit on this branch (`4175b26e`, "Prevent Infinite Loop in OverlappingFieldsCanBeMergedRule") was hardening this same rule.

The remedy is to finish the reframing the diff started. The canonical string is a property of one field node and does not depend on the field it is compared with, so it should be computed at most once per node and skipped entirely when the node has no arguments. Keep `stringifyArguments` as the single concept, return early with an empty string when `args.length === 0`, and memoize the result per `FieldNode`. I prototyped exactly that outside the clone. With the early return alone, the argument-less case returns to base speed (74 ms for 1000 repetitions) but the argument-heavy case stays at 2553 ms. With the early return plus a per-node memo, the argument-less case is at base speed (66 ms) and the argument-heavy case drops from 2167 ms at the base to 16 ms for 200 repetitions. All 521 tests under `src/validation/__tests__` pass against both prototypes.

The memo can be a module-level `WeakMap<FieldNode, string>` as prototyped, or a `Map` created in the rule's `SelectionSet` visitor next to `cachedFieldsAndFragmentNames` and threaded the same way. The second is more consistent with how this file already owns its per-validation caches, at the cost of one more parameter on an already long parameter list. Either is acceptable; recomputing per pair is not.

The change also ships with no benchmark or test that would have caught this. `benchmark/` has `validateGQL-benchmark.js` and `validateInvalidGQL-benchmark.js`, but neither exercises many fields sharing a response name. A small benchmark of that shape would keep this from regressing again.

Full measurements, commands, and the worked proposal are in [01_overlapping_fields_argument_comparison.md](01_overlapping_fields_argument_comparison.md).
Consequence: —
Fix: —

### Item 2
Location: src/validation/rules/OverlappingFieldsCanBeMergedRule.ts:637-650
Claim: Is the changed result for duplicated argument names intended, and should a test pin it? For `{ f(a: 1, a: 2) f(a: 1, a: 2) }`, the base reports `Fields "f" conflict because they have differing arguments` and the head reports nothing, because the base looked up each argument by name with `find` and always hit the first `a`. The head's answer is the better one (the two fields are textually identical, and `UniqueArgumentNamesRule` reports the duplicate on its own), but the commit is titled as a simplification and no test covers the case in either direction. Evidence is in the detail file under "Behavior comparison".
Consequence: —
Fix: —
