# Review blind-e0bcb4

### Item 1
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:24
Claim: The path override is now gated on a client-controllable `x-vercel-isr: 1` header, re-opening the untrusted path override that #15959 closed; the same entrypoint is used for both `_render` and `_isr`.
Consequence: Confirmed in-process against the built `_render` handler: `GET /api/public?x_astro_path=/api/private` with header `x-vercel-isr: 1` returns `{"id":"private"}` (without the header it returns `public`). If Vercel does not strip this header from inbound requests, an attacker renders any route while path-based rules and edge middleware see `/api/public`.
Fix: —

### Item 2
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:25
Claim: On genuine ISR invocations the `x_astro_path` value is trusted without validation, so the `_isr` function can be pointed at any route, including routes in `isr.exclude` or behind edge middleware.
Consequence: A client requests `/_isr?x_astro_path=/excluded/secret` directly. The platform adds `x-vercel-isr: 1` itself, the handler rewrites to `/excluded/secret`, and the response is rendered without edge middleware and stored in the ISR cache (`allowQuery` keys on `x_astro_path`). No header spoofing is needed.
Fix: —

### Item 3
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:24
Claim: The fix assumes every ISR function invocation carries `x-vercel-isr: 1`, which is undocumented; invocations without it still get no path rewrite.
Consequence: An on-demand revalidation (`x-prerender-revalidate: <bypassToken>`) or bypass-cookie request invokes `_isr` without the header. `realPath` stays undefined, Astro matches `/_isr` instead of `/one`, and the 404 is returned or cached. Not verifiable offline; in-process, `/_isr?x_astro_path=/api/one` without the header is not rewritten.
Fix: —

### Item 4
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:25
Claim: Reading the path through `searchParams.get` form-decodes it, so paths containing `+`, `&`, `#` or percent-escapes are mangled before being assigned to `url.pathname`.
Consequence: Confirmed in-process: `x_astro_path=/api/a+b` renders with `params.id === 'a b'`, and `x_astro_path=/api/a&b=c` is truncated to `/api/a`. If Vercel substitutes `$0` raw, a request to `/api/a+b` served via ISR renders the wrong page or 404s and caches it.
Fix: —

### Item 5
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:28
Claim: After the rewrite, the internal `x_astro_path` param is left in the request URL, so user code sees it in `Astro.url` / `request.url`.
Consequence: An ISR request for `/one` reaches the app as `https://host/one?x_astro_path=/one` (confirmed with the URL setter). Canonical URLs, `Astro.url.search`, pagination links or redirects built from the URL include the internal param and get cached in the ISR output.
Fix: —

### Item 6
Location: packages/integrations/vercel/test/path-override-security.test.js:30
Claim: No test was added for the new ISR branch, and the existing security tests do not cover the `x-vercel-isr` header, so both the fix and the re-opened override are unguarded.
Consequence: The suite passes (4/4) while `_render` honours `x_astro_path` with a spoofed header. A future refactor can break ISR rewriting again, as #15959 did, or widen the override, with no failing test.
Fix: —

### Item 7
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:22
Claim: Altitude: a runtime header heuristic decides whether the function is the ISR function, instead of a build-time distinction between `_isr` and `_render`.
Consequence: `buildISRFolder` and `buildServerlessFolder` share one entry, so `_render` and the edge-middleware target also accept the query override whenever the header is present. A build-time flag or separate entry for `_isr`, with the param validated against ISR-eligible routes, would confine the override to the function that needs it.
Fix: —

### Item 8
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:28
Claim: Pre-existing bug in the touched function: the middleware sends path plus query in `x-astro-path`, and assigning that to `url.pathname` percent-encodes the `?`.
Consequence: With edge middleware, a request to `/foo?a=1` sets `x-astro-path: /foo?a=1`. `url.pathname = '/foo?a=1'` yields `https://host/foo%3Fa=1` (confirmed in node), so route matching sees `/foo%3Fa=1` and the query string is lost.
Fix: —

### Item 9
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:21
Claim: `let realPath = undefined;` is untyped (evolving `any`), and the new block is unformatted: `if(` without a space and a missing semicolon on line 23.
Consequence: The previous `const` had type `string | null`; the new variable loses that explicit type, and the block will be rewritten by the repo's format step, adding a follow-up `[ci] format` commit. An explicit `string | null` declaration restores the old typing.
Fix: —

### Item 10
Location: .changeset/common-cats-travel.md:5
Claim: The changeset text "Fix vercel ISR path rewrite" does not describe the user-visible problem being fixed.
Consequence: The changelog entry does not tell users that ISR-served routes returned 404 after the previous patch, so affected users cannot tell that this release fixes their regression.
Fix: —
