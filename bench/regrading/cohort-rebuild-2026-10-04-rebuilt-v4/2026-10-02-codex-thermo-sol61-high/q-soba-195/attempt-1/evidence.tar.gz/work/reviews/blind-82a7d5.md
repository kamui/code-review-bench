# Review blind-82a7d5

### Item 1
Location: internal/backup.go:105-114
Claim: In `internal/backup.go:105–114`, the new `tokenProviders` table centralizes backup execution, but provider policy still resides separately in `enabledProviderAuth`, `justTokenProviders`, and `userAndPasswordProviders` in `internal/constants.go:120–159`. The extracted `checkProvider` path at `internal/backup.go:326–395` still dispatches through those lists and passes a mutable error builder into helpers whose integer results mean different things: populated parameters for Gitea/Sourcehut and complete credential tuples for Azure DevOps. A provider change therefore requires coordinating selection, validation parameters, and validation policy across independent declarations. This split predates the PR, but the new table and helper extraction preserve it instead of completing the structural simplification. Define one ordered, typed descriptor for each ordinary provider containing its execution gate, validation parameters, validation policy, and backup function; use it for both collection and startup validation. Keep Bitbucket's alternative authentication methods explicit. This lets the parallel classification lists and string-based dispatch disappear while preserving the existing distinction between a configuration that counts toward startup validation and credentials that trigger execution. Full evidence and a worked replacement are in [01_backup_runtime.md](01_backup_runtime.md).
Consequence: —
Fix: —

### Item 2
Location: internal/backup.go:473-478
Claim: In `internal/backup.go:473–478`, the new `createWorkingDir` helper repeats the `GIT_WORKING_DIR` lookup and `.working` fallback already owned by `resolveWorkingDir` at lines 140–145, which backup execution uses at line 52 to choose the directory passed to cleanup. The extraction makes this duplicated policy a separate named startup operation without giving it a shared source of truth. A later change to the fallback or environment handling can make startup create one directory while execution selects another for cleanup. Initialize `workingDIR` with `resolveWorkingDir(backupDIR)` and retain the existing logging, path cleaning, permissions, and wrapped error. The two implementations currently agree; this is a canonical-helper reuse finding, not an observed path failure. The exact replacement and equivalence checks are in [01_backup_runtime.md](01_backup_runtime.md).
Consequence: —
Fix: —
