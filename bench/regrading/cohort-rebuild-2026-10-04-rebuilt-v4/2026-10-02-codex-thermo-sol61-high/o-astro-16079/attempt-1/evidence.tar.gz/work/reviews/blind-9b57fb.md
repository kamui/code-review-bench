# Review blind-9b57fb

### Item 1
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:24-25
Claim: In `packages/integrations/vercel/src/serverless/entrypoint.ts:24–25`, the new `x-vercel-isr === '1'` branch lets a request header authorize `x_astro_path` rewriting in every instance of the shared handler, without a valid middleware secret or an ISR-specific execution context. Calling the built `_render` handler for the fixture with ISR disabled at `/api/public?x_astro_path=/api/private` returns the fixture response `{"id":"private"}` when that header is present, whereas the same request without it returns `{"id":"public"}`; an invalid middleware secret does not prevent the rewrite. This leaks ISR transport policy into ordinary route matching and replaces the previous authenticated rewrite boundary with an implicit platform-header trust assumption. Bind query-based restoration to the generated ISR entry, preserve authenticated middleware forwarding in the ordinary handler, and explicitly establish the provenance of any remaining request-controlled rewrite signal. Add handler tests covering the successful ISR request and the combined header/query attack on `_render`, including an ISR-disabled build. This is a reproduced adapter-boundary regression; it is not a verified Vercel deployment exploit. [Full evidence and worked restructuring](01_isr_request_boundary.md).
Consequence: —
Fix: —

### Item 2
Location: (no file)
Claim: Does Vercel strip or overwrite a client-supplied `x-vercel-isr` header before invoking both `_render` and `_isr`, including excluded routes and direct function paths? The checkout provides no such guarantee, and the offline execution policy prevents checking it. Establish this contract before treating the header as trusted routing metadata; the in-process route substitution alone does not establish an edge-middleware or firewall bypass in production.
Consequence: —
Fix: —
