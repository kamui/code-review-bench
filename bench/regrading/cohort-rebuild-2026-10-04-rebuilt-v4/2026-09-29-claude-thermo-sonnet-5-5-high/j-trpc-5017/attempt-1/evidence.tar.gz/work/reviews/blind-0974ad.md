# Review blind-0974ad

### Item 1
Location: packages/server/src/core/internals/utils.ts:11-30
Claim: **1. `Overwrite` in `packages/server/src/core/internals/utils.ts` (lines 11–30) is roughly four times longer than it needs to be; the redundant branches should be deleted.** The new type has two separate fall-through arms that both return `TWith`, and each wraps the result in a `TWith extends any ? TWith : never` conditional. That conditional is the identity function: a distributive `X extends any ? X : never` returns `X` for every input including `never`. The outer `TType extends any ? … : never` in the non-object arm is likewise always-true. The whole thing collapses to `TType extends object ? (TWith extends object ? <key-by-key mapped type> : TWith) : TWith`. I checked this with the repo's own `tsc` against 21 type pairs (string/string, object/object, never on either side, unions on either side, `any`, `unknown`, arrays, `undefined`, optional keys) and the simplified form is identical to the PR's version in every case. The code-judo here is that the "only merge when both are objects, otherwise the right side wins" rule reads directly off a two-level conditional; the current version makes a reader work out that three of its arms are the same arm. See `01_overwrite-type.md` for the measurements and the proposed replacement. Verification status: confirmed by compilation.
Consequence: —
Fix: —

### Item 2
Location: packages/server/src/core/internals/utils.ts:4-29
Claim: **2. The doc comment on `Overwrite` (utils.ts lines 6–9) and the `: TType` arm (line 29) promise behaviour that does not exist.** The comment says non-object cases overwrite the whole of `TType` "unless TWith is never", and line 29 is written so that a `never` `TWith` yields `TType`. In fact `TWith` is the checked type in a distributive conditional, so `never` distributes to `never` before either arm is chosen; `Overwrite<string, never>` and `Overwrite<{a: 1}, never>` both evaluate to `never`, exactly as they did before the PR. The `: TType` arm is unreachable, and the comment invites readers, and later callers, to rely on a "keep the old value when the new one is never" behaviour that is not there. Either delete the arm and correct the comment to say that `never` propagates (which is what finding 1's shape does naturally), or, if keep-on-never was really intended, implement it with a non-distributive check (`[TWith] extends [never]`) and test it. Verification status: confirmed by compilation (`Overwrite<string, never>` and `Overwrite<{a:1}, never>` both resolve to `never`); see `01_overwrite-type.md`.
Consequence: —
Fix: —

### Item 3
Location: packages/tests/server/regression/issue-5020-inference-middleware.test.ts:1-40
Claim: **3. The regression test in `packages/tests/server/regression/issue-5020-inference-middleware.test.ts` does not cover the bug class it is named after, and carries scratch residue.** The router declares `voidWithMiddleware` (lines 13–17) but no assertion ever reads it, so the "no input plus middleware" half of the scenario is dead setup. Only `string` is exercised; there is no object-input-plus-middleware or chained-`.input()` merge case, even though those are the paths that go through the key-by-key arm the PR touched, and no direct assertions on `Overwrite` for the primitive/object/never combinations that the PR's own doc comment describes. `// ^?` twoslash markers are left in at lines 8 and 30 and are noise in a committed test; the test callback is `async` with no `await`. The file name also says 5020 while the PR is #5017 and the review thread referenced `issue-5017-…`, which makes the regression file hard to trace to its ticket; pick the real issue number. Add a short assertion block for `voidWithMiddleware` (`expectTypeOf<AppRouterInputs['voidWithMiddleware']>()` against `void`/`undefined`, whichever is intended), one object-input case, and a small `Overwrite` matrix test, and drop the debug markers. Verification status: confirmed by reading; see `02_regression-test.md`.
Consequence: —
Fix: —

### Item 4
Location: (no file)
Claim: Is it intended that an object `TType` is fully replaced when `TWith` is a non-object such as `undefined` or `string` (for example `Overwrite<{a: 1}, undefined>` is `undefined`)? For `_ctx_out` and `_input_*` this is likely fine, but it is a silent replacement where the pre-PR code produced a (mangled) object, and it is not covered by any test or by the doc comment.
Consequence: —
Fix: —

### Item 5
Location: (no file)
Claim: The PR description is the untouched template and seven of eight commits are `wip`/`ok`/`nah`/`revert`/`col`/`rename`; is a squash message planned that states the `Overwrite<string, string>` root cause so `git blame` is useful later?
Consequence: —
Fix: —
