# Review blind-ae3eea

### Item 1
Location: src/utils/body.ts:126
Claim: parseFormData now reads request.arrayBuffer() instead of request.formData(). When formData is already in HonoRequest.bodyCache, HonoRequest rebuilds the buffer by re-serializing the cached FormData with a new boundary, which no longer matches the original Content-Type.
Consequence: A handler calls `await c.req.formData()` and then `await c.req.parseBody()`. Before this PR that returned the cached FormData. I ran it on review-head. A multipart POST returns 500 with 'TypeError: Failed to parse body as FormData'. A urlencoded body `m=hello` returns garbage: `{"------formdata-undici-…\r\nContent-Disposition: form-data; name": "\"m\"\r\n\r\nhello…"}`. The garbage case is silent data corruption. Middleware that calls `c.req.formData()` before a handler that calls `parseBody()` is affected. On main this scenario returned `{m:'hello'}`.
Fix: —

### Item 2
Location: src/utils/body.ts:128
Claim: parseFormData overwrites `request.bodyCache.formData` with a raw Promise cast to FormData (`as unknown as FormData`). It does this unconditionally, and the cached promise may be rejected.
Consequence: The BodyCache type says the `formData` slot holds a FormData. The validator stores a resolved FormData there, while parseBody stores a Promise, so the slot has two shapes. Any consumer that reads `bodyCache.formData` synchronously gets a Promise. If bufferToFormData rejects, for example on a malformed multipart body, the rejected promise stays cached. A later `c.req.formData()` then returns the same rejection instead of trying again. The unconditional assignment also replaces any FormData another caller cached while `arrayBuffer()` was pending.
Fix: —

### Item 3
Location: src/utils/body.ts:122
Claim: For a plain `Request` (not HonoRequest), parseBody now buffers the whole body with arrayBuffer() and re-wraps it in a new Response. It used to call the native, one-pass `request.formData()`.
Consequence: Large multipart uploads are held in memory as an ArrayBuffer and then parsed again from a copy inside bufferToFormData, which roughly doubles peak memory. Code or tests that stub `request.formData`, as the removed `vi.spyOn(req, 'formData')` test did, no longer affect parseBody. The Content-Type case fix did not need this change, because the media type check alone would have fixed parseBody.
Fix: —

### Item 4
Location: src/utils/body.ts:104
Claim: parseBody's guard changed from `startsWith` to exact media-type equality. The media type is now normalized in three separate ways: split/lowercase in body.ts, `/i` regexes in validator.ts, and a `replace(/^[^;]+/)` in buffer.ts.
Consequence: The three places can drift apart. The validator regexes are strict about parameters and allow at most one space after `;` in multipart, while parseBody accepts any parameters. The same header can therefore be accepted by parseBody and skipped by validator('form'), or the reverse. A shared `getMediaType()` helper would keep them consistent. The bufferToFormData replace also re-lowercases a value the caller already checked.
Fix: —

### Item 5
Location: src/validator/validator.ts:24
Claim: The `/i` flag was added to the whole regex, so it also makes parameter names and values, and the `[a-z-.]+` structured-suffix group, case-insensitive, not just the media type. The validator still passes the un-normalized header to bufferToFormData.
Consequence: The issue asked for case-insensitive matching of the media type portion only. The regex now also accepts values such as `application/Vnd+JSON`, which is fine. The real gap is that the multipart regex still restricts boundary characters and allows only `;\s?boundary=`, so a mixed-case `Multipart/Form-Data; charset=utf-8; boundary=x` is silently skipped, giving `{}` downstream. That is the same class of silent skip the PR set out to fix.
Fix: —

### Item 6
Location: src/validator/validator.test.ts:1
Claim: The tests do not cover the interaction that broke, namely `c.req.formData()` followed by `parseBody()`, nor a body that fails to parse.
Consequence: Codecov flagged 4 uncovered patch lines in body.ts and buffer.ts. The new `bodyCache.formData` caching branch and the `bufferToFormData` failure path in parseFormData have no test, which is why the formData-then-parseBody regression went unnoticed. The old test that mocked `formData` was rewritten instead of being kept alongside a cache-interaction test.
Fix: —
