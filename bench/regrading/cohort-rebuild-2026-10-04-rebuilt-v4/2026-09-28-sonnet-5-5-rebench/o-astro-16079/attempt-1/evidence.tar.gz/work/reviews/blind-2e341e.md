# Review blind-2e341e

### Item 1
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:24
Claim: The path override is trusted on a client-controllable `x-vercel-isr: 1` header, which reopens the path-override hole that #15959 closed.
Consequence: The previous commit (#15959, 'Require trusted secret for path overrides') limited the override to requests carrying the middleware secret. This branch also honours `x_astro_path` when the request has `x-vercel-isr: 1`. That header is a plain request header, and nothing in the code shows the platform strips it from external requests. It is also read on every function built from this entrypoint, including `_render`, not only `_isr`. I built the `serverless-with-dynamic-routes` fixture and called the `_render` handler in-process with `GET /api/public?x_astro_path=/api/private` and header `x-vercel-isr: 1`. The body was `{"id":"private"}`. Without the header the same request returns `public`. An attacker can therefore make the function render a different route than the URL that edge middleware authorised. That defeats middleware-based auth and path checks. The existing `path-override-security.test.js` still passes because it never sends the header.
Fix: —

### Item 2
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:24
Claim: The fix has no regression test, and the security tests do not cover the new branch.
Consequence: No test in `isr.test.js` or `path-override-security.test.js` calls the `_isr` handler with `x-vercel-isr: 1` and `x_astro_path`. It could not have caught the original 404. The security tests only send the query param or `x-astro-path` header without `x-vercel-isr`. Neither the functional fix nor its trust boundary is guarded, so the spoofing above and any future ISR 404 can return unnoticed.
Fix: —

### Item 3
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:25
Claim: The internal `x_astro_path` query param is left in the rewritten URL, so it leaks into `Astro.url.searchParams` and `request.url`.
Consequence: After the rewrite only `url.pathname` is set. The search string still contains `?x_astro_path=/one`, because ISR is configured with `passQuery: true` and `allowQuery: ['x_astro_path']`. User code sees `Astro.url.search === '?x_astro_path=%2Fone'` and `request.url` includes the internal param. Pages that iterate over or validate query params see an unexpected key, and canonical URLs built from `Astro.url` include the internal parameter. The code should call `url.searchParams.delete(ASTRO_PATH_PARAM)` before building the new Request.
Fix: —

### Item 4
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:25
Claim: The ISR path comes from a decoded query value, so percent-encoded path characters can change the route.
Consequence: `$0` is substituted into the query string of the rewrite destination. `searchParams.get` percent-decodes the value, and `url.pathname = realPath` assigns it as if it were already a path. A request to `/a%2Fb` yields `/a/b`. A request containing `%2E%2E` yields `..`, which the URL parser normalises. The route matched by `app.match` can then differ from the original encoded path, giving a wrong page or 404 for dynamic routes with encoded segments.
Fix: —

### Item 5
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:24
Claim: The `x-vercel-isr` header name is a magic string, and the ISR check is not tied to the ISR function.
Consequence: `ASTRO_PATH_HEADER` and `ASTRO_PATH_PARAM` are exported constants from `../index.js`, but `'x-vercel-isr'` is an inline literal with no comment explaining why it is used or whether Vercel sets it. The entrypoint is shared by the `_render` and `_isr` functions and does not know which one it is running as. The ISR rewrite is enabled everywhere instead of only for the `_isr` function, which is what makes the spoofing possible. Baking a flag into the ISR build (as the earlier 'ISR secret plumbing' approach did), or checking the function name, would restrict it.
Fix: —

### Item 6
Location: packages/integrations/vercel/src/serverless/entrypoint.ts:21
Claim: The new block ignores the repo's Biome formatting and types `realPath` loosely.
Consequence: The lines `if(hasValidMiddlewareSecret) {` and `} else if(...) {` have no space after `if`. `realPath = request.headers.get(ASTRO_PATH_HEADER)` has no semicolon. Both break the Biome rules that AGENTS.md says are enforced ("Our rules are defined in our biome.jsonc file, enforced by Biome"), so `pnpm format` or lint will rewrite or flag them. `let realPath = undefined;` is inferred as `any` or `string | null | undefined`. It should be `let realPath: string | null = null;`.
Fix: —

### Item 7
Location: .changeset/common-cats-travel.md:5
Claim: The changeset text is vague and does not say what was broken or that ISR routes returned 404.
Consequence: "Fix vercel ISR path rewrite" ends up in the `@astrojs/vercel` changelog. Users who hit 404s on every ISR route after upgrading past #15959 cannot tell from it that the regression is fixed. It also does not mention that the fix reads a request header.
Fix: —
