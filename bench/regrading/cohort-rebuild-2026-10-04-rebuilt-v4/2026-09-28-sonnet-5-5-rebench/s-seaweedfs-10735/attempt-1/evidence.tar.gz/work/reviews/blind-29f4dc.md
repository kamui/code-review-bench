# Review blind-29f4dc

### Item 1
Location: weed/filer/redis2/universal_redis_store.go:245
Claim: The restore decision is made from a non-atomic EXISTS, and a stale positive result can make the cleanup itself re-add an orphan.
Consequence: The listing runs ZREM and then EXISTS, which returns 1 because a concurrent InsertEntry has just written the value. DeleteEntry (or an expiry) then removes the value and finishes its own ZREM before the listing's ZAddNX runs. The listing's ZAddNX then re-adds the member for a value that no longer exists, leaving a fresh orphan. The next listing has to clean it up again. This is benign and self-healing, but the 'converges' claim only holds for the insert interleavings. The PR does not justify the ZREM, EXISTS, ZAddNX design with respect to delete interleavings.
Fix: —

### Item 2
Location: weed/filer/redis2/universal_redis_store.go:238
Claim: removeOrphanedDirectoryListMember swallows all errors with no logging. This includes ZREM failures and the ZAddNX restore, whose failure can leave a live entry invisible.
Consequence: If the ZAddNX restore fails (connection blip, or a cluster MOVED/READONLY error), the live value has no index member. UpdateEntry never re-adds the member, so the entry stays invisible to ListDirectoryEntries and DeleteFolderChildren until another InsertEntry hits that exact path. Nothing is logged, so the loss is undiagnosable. The PR text says errors are 'no longer discarded outright', but the ZAddNX result is still discarded and the ZREM error is dropped silently.
Fix: —

### Item 3
Location: weed/filer/redis2/universal_redis_store.go:219
Claim: The logical-expiry branch is left unfixed with the same race, and it is the worse variant. It does a plain DEL of the value followed by ZREM, with no compensation.
Consequence: A concurrent InsertEntry for the same path lands between FindEntry and the DEL. The listing deletes the freshly written value, and ZREM then removes the member. The new entry is lost entirely. The PR says this is deliberately out of scope. The new helper shows the fix pattern is known, yet the same function now has two inconsistent cleanup strategies for the same orphan-member situation.
Fix: —

### Item 4
Location: weed/filer/redis2/universal_redis_store.go:237
Claim: The new helper takes both `path` and `fileName`, although path is derivable from them. It also duplicates the ZREM logic the expiry branch has inline, so there are now two different cleanup implementations in one loop.
Consequence: The two ways of removing a stale index member have different safety properties. Maintainers editing one are likely to miss the other. The `path` parameter is used only to rebuild the value key that the caller already computed.
Fix: —

### Item 5
Location: weed/filer/redis2/universal_redis_store.go:207
Claim: Each orphan costs up to 3 extra sequential round trips (ZREM, EXISTS, and ZAddNX on the restore path), inside a per-member loop that already issues one GET per member. The glog.V(0) line also still fires once per orphan.
Consequence: Listing a directory with many dead members (a big TTL backlog on first listing after upgrade) issues 3 extra round trips per orphan, in addition to the GET already made. That makes the first listing much slower. The cleanup could be batched, for example one pipelined ZREM of all not-found members after the loop, followed by a single pipelined EXISTS. The unconditional V(0) log line also keeps producing one line per dead member on that first listing.
Fix: —

### Item 6
Location: weed/filer/redis2/universal_redis_store_test.go:96
Claim: The tests cannot fail in CI. They all skip without RUN_REDIS_TESTS=1, and the concurrent-recreate test does not exercise the real race or the Exists-error restore branch.
Consequence: TestRemoveOrphanedDirectoryListMemberKeepsRecreatedEntry calls the helper directly on a live entry. It does not cover the exists==0 removal path, the ZREM-error path, or the Exists-error restore path. Nothing in default CI runs any of these tests against Redis. A regression of the compensation logic would not be caught outside a manual run with a server.
Fix: —

### Item 7
Location: weed/filer/redis2/universal_redis_store_test.go:27
Claim: Test setup and cleanup are fragile on a shared Redis and use a wall-clock TTL sleep.
Consequence: The unique directory name is time.Now().UnixNano(). t.Cleanup ignores all errors and does not delete the per-entry value keys of orphaned or expired entries that are no longer in the index. The Redis-expiry test sleeps 1.5s and asserts Redis has already expired the key, which is timing-dependent and can flake under a loaded server or a slow clock. It also asserts on the state of the entry before Redis's active or lazy expiry, so failures would be reported as a code bug.
Fix: —

### Item 8
Location: weed/filer/redis2/universal_redis_store.go:205
Claim: ListDirectoryEntries counts orphan members against `limit` (ZRangeByLex Count: limit). Cleaning them up in place still returns fewer entries than requested, and callers may read that as end-of-directory.
Consequence: A directory has limit=100 and 60 orphans within the first 100 lexicographic members. The listing removes them and returns only 40 live entries. Callers that treat a short page as end-of-listing (for example the filer's paged loop, which stops when fewer than limit entries come back) skip live entries beyond the 100th member. This is pre-existing. The new cleanup makes the effect more visible, and it is only cured after a repeat listing.
Fix: —
