# Review blind-74282a

### Item 1
Location: internal/backup.go:326-395
Claim: In `internal/backup.go:326–395`, `checkProvider` now dispatches to two helpers that return a count while mutating its caller-owned `*strings.Builder`. The user/password helper still scans every credential to count it and then reads every credential again to reconstruct missing-parameter diagnostics. This extraction expands the validator from 49 to 70 lines and makes its result depend on two output channels without removing the repeated read/format flow. Since `GetEnvOrFile` can open files and log failures, the second pass is more than a repeated map lookup. Replace the two builder-mutating helpers with one credential scan that records valid and missing parameters, applies the existing token-versus-all-required policy, and returns the count and error together. Preserve the existing distinction between absent and explicitly blank token settings and the existing diagnostic wording. [Full evidence and a worked replacement](01_backup.md#credential-validation).
Consequence: —
Fix: —

### Item 2
Location: internal/backup.go:473-478
Claim: In `internal/backup.go:473–478`, the new `createWorkingDir` helper repeats the `GIT_WORKING_DIR` lookup and default-path construction already owned by `resolveWorkingDir` at lines 140–146. Backup cleanup uses that resolver, while startup directory creation keeps a second implementation of the same choice. A future change to the default or override rules would therefore require synchronized edits to creation and cleanup. Initialize `workingDIR` with `resolveWorkingDir(backupDIR)` and leave logging, cleaning, permissions, and error wrapping in `createWorkingDir`. This removes the duplicated policy without changing current path selection. [Full evidence and the small replacement](01_backup.md#working-directory-resolution).
Consequence: —
Fix: —

### Item 3
Location: internal/backup_test.go:651-681
Claim: In `internal/backup_test.go:651–681`, `assertGiteaOrgTwoOnlyBackedUp` and `assertGiteaAllOrgsBackedUp` repeat the same org-two directory read, cardinality assertion, and two repository-prefix assertions. The caller still switches on the organization selector to choose between these helpers. The extraction removes local nesting but leaves the common scenario checks in two places, so adding another selection case requires another assertion body or further helper nesting. Put the selector and expected organization-to-repository-prefix map in a table, and use one assertion helper to compare both known organization directories against that map, including the absent-org assertion. Keep the exact entry counts, timestamp-tolerant prefix checks, and per-iteration cleanup. This deletes the scenario switch and both overlapping assertion bodies while preserving the current checks. [Full evidence and a worked table-driven form](02_backup_tests.md#gitea-organization-scenarios).
Consequence: —
Fix: —
