# Review blind-3599c0

### Item 1
Location: pkg/scheduler/schedule_one.go:58-61
Claim: `pkg/scheduler/schedule_one.go:58-61` and `pkg/scheduler/schedule_one.go:851-858`. Before this PR the compiler tied the scheduler's truncation length to the validator's limit. After it, the only thing connecting `noteLengthLimit = 1024` to `NoteLengthLimit` in `pkg/apis/core/validation/events.go:37` is the prose in the comment, and nothing in the tree would fail if either number were edited. `truncateMessage` has no test of its own: the two references in `schedule_one_test.go` (lines 2098 and 5062) call it from replacement failure handlers to build the message, so they would agree with any value. The drift risk is small, because the limit is also written into the `events.k8s.io/v1` `Note` field documentation and lowering it would break clients, but the PR trades a compile-time guarantee for an unchecked one and should say so with a test rather than a sentence. The cheapest fix is a table test for `truncateMessage` at 1023, 1024 and 1025 bytes that asserts the output length and the ` ...` suffix. That pins the behaviour inside the package without needing the forbidden import. If the authors want the two constants compared directly, that check has to live outside `pkg/scheduler`, for example in `test/integration/scheduler`, whose import rules do not forbid `pkg/apis/core/validation`.
Consequence: —
Fix: —

### Item 2
Location: pkg/scheduler/schedule_one.go:58-61
Claim: `pkg/scheduler/schedule_one.go:58-61`. The note limit is part of the `events.k8s.io/v1` API contract, not scheduler policy, and `staging/src/k8s.io/api/events/v1/types.go:81-83` already documents it in prose ("Maximal length of the note is 1kB"). `k8s.io/api` is where the tree keeps this kind of number: `ResourceHealthMessageMaxLength = 1024` and `MaxSecretSize` in `core/v1/types.go`, and the `*MaxSize` and `*MaxLength` family in `resource/v1/types.go`. The code-judo move is to declare the note limit once next to the `Note` field, have `pkg/apis/core/validation/events.go` use that declaration, and have the scheduler import `k8s.io/api/events/v1`, which is a staging module and therefore compatible with the move this PR is preparing. That removes the k/k import and the duplicated literal at the same time, and the "safe even if stale" paragraph is no longer needed because nothing can go stale. A further step would be to truncate inside the `client-go/tools/events` recorder, since the scheduler is the only in-tree caller that truncates at all and every other user of that recorder has the same exposure; that would delete `truncateMessage` from the scheduler outright. Both steps add exported surface or change shared behaviour in staging modules and need API review, so I would accept the local copy for this PR and treat the relocation as a follow-up. It is worth a `TODO` on the constant so the copy is not mistaken for the end state.
Consequence: —
Fix: —

### Item 3
Location: (no file)
Claim: Commit `d9cf69d74a25`. The message body ends with `# Conflicts:` and `#	pkg/scheduler/schedule_one.go`, which is the residue git appends when a cherry-pick or rebase stops on a conflict. This repository merges commits without squashing, so those lines would land in history. Amend the message to drop them.
Consequence: —
Fix: —
