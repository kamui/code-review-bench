# Review blind-75e793

### Item 1
Location: packages/react/src/field/control/FieldControl.tsx:105-158
Claim: **1. Two copies of the "sync field state" sequence, with the filled logic split across three places.** In `packages/react/src/field/control/FieldControl.tsx`, the controlled path (`useValueChanged` at lines 105-115) runs `clearErrors`, `setDirty(v !== (validityData.initialValue ?? ''))`, `setFilled(v !== '')` and `validation.change(v)`. The uncontrolled `onChange` (lines 137-158) runs the same four steps inline, with a comment that the order matters because `validation.change` reads `markedDirtyRef`. "Filled" now has three writers: a mount-only layout effect (lines 99-103), the hook, and `onChange`. The ordering invariant lives in two places, so the next edit to one will drift from the other. This is the spaghetti-growth pattern the review standards flag: a mode branch (`if (isControlled) return;` at line 144) bolted into the middle of an already busy handler. The code-judo move is a single local `syncFieldState(nextValue: string)` that owns the clear, dirty, filled and validate sequence, called from the uncontrolled `onChange` and from the hook. The `isControlled` early return and the duplicated comment then disappear. The `serializedValue === undefined` guard inside the hook (line 106) is the same mode flag again and can go away if the hook body is only reached for controlled values. A more ambitious option is to feed uncontrolled input through the same `useValueChanged` path by tracking the last-seen DOM value in a ref, which would delete the branch entirely. The existing "avoids rerendering for uncontrolled input changes" test would need to keep passing. Detail: `01_field-control.md` section A.
Consequence: —
Fix: —

### Item 2
Location: packages/react/src/field/control/FieldControl.tsx:144-153
Claim: **2. `details.cancel()` and `defaultPrevented` only take effect in uncontrolled mode.** The PR says `details.cancel()` "now stops the internal handling". In the code, the `!defaultPrevented && !details.isCanceled` guard (line 153) sits after the `if (isControlled) return;` (line 144), so it is unreachable for controlled controls. In controlled mode the field state follows the prop echo, which never looks at the event details. A consumer who calls `details.cancel()` but still calls `setValue`, or whose native `input` event was prevented, now gets `clearErrors`, dirty/filled updates and validation anyway. That is a regression for the prevented-change case in controlled mode (the existing "does not clear errors or validate when change is prevented" test only covers the uncontrolled case). It also makes cancel semantics differ by mode, which is hard to explain in docs. The new cancel test is also uncontrolled-only. The remedy is to decide the controlled semantics explicitly. Either record "this change was canceled" in a ref set by `onChange` and consumed by the echo, or state in the docs and a test that controlled consumers cancel by not updating `value`. Add a controlled test either way. Detail: section B.
Consequence: —
Fix: —

### Item 3
Location: packages/react/src/field/control/FieldControl.tsx:119-163
Claim: **3. The PR description claims code that is not in the diff.** The body says `processedValueRef` guards the double-validation echo and that a control that unmounts or becomes disabled while focused no longer latches `data-focused`. Neither exists on `review-head`. `setFocused` is only called from `onFocus`, `onBlur` and the autofocus effect (lines 119-123, 159-163). There is no `processedValueRef`. The double-validation concern is handled differently, by skipping field-state updates in the controlled `onChange`, which is arguably the simpler design. The focused-latch fix is simply missing. The body also says this PR does not call `clearErrors` on programmatic change, but the new hook does (line 110), so the "open question" is already answered in code the opposite way. Either the description is stale or the intended fixes were dropped. The author should reconcile them before merge; as written, a reviewer cannot tell which behavior is intended. Detail: section C.
Consequence: —
Fix: —

### Item 4
Location: packages/react/src/field/control/FieldControl.tsx:86-94
Claim: **4. Serializing the registered value changes the registration contract for Form-level validation.** `useRegisterFieldControl` receives `serializedValue` (lines 86-94). In `useFieldControlRegistration.ts`, `getRegistrationValue` prefers `registration.value` over the DOM getter, and both the captured `initialValue` and the form-submit/`validate()` path (`commit(getRegistrationValue(...))`) use it. A controlled `value={5}` or array value therefore now reaches `validate` callbacks as `"5"` or `"a,b"` at submit time instead of the original value. On-change validation already received the DOM string, so this arguably makes things consistent, but it is an undocumented behavior change with no test. `String(value)` is also a hand-rolled approximation of the DOM's value coercion that is now load-bearing for dirty comparison. Keep the serialization, but name it as the field's baseline contract (a one-line helper beside the registration), and add a test that pins what `validate` receives on submit for a numeric controlled value. Detail: section D.
Consequence: —
Fix: —

### Item 5
Location: packages/react/src/field/control/FieldControl.tsx:110
Claim: The description's "open question" about `clearErrors` is already resolved in the diff: both the hook and the uncontrolled handler call `clearErrors(name)`. Which behavior is intended?
Consequence: —
Fix: —
