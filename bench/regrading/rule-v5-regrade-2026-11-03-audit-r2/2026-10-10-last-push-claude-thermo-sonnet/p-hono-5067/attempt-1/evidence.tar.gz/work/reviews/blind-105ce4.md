# Review blind-105ce4

### Item 1
Location: src/utils/body.ts:121-138
Claim: **1. `parseFormData` was rewritten beyond what the fix needs (src/utils/body.ts:121-138).** The issue is the guard at the top of `parseBody`. The new `mediaType` check at src/utils/body.ts:104-106 already fixes it. Instead of leaving `request.formData()` alone, the PR now calls `arrayBuffer()`, runs `bufferToFormData`, and for `HonoRequest` assigns a Promise into `bodyCache.formData` using `as unknown as FormData`. That is a second copy of the arrayBuffer/bufferToFormData/cache sequence already in src/validator/validator.ts:118-121, but with different cache semantics (resolved value there, Promise here, one typed slot). It also duplicates the `request instanceof HonoRequest ? request.raw.headers : request.headers` lookup inside the same file, buffers plain `Request` bodies fully in memory where they used to be handled by the platform, and forced the existing "dot" test to be rewritten because it mocked `formData()`. I probed Node v24.21.0 and mixed-case `Application/X-WWW-Form-Urlencoded` and `Multipart/Form-Data; boundary=...` already parse through `Request.formData()` natively; I could not run other runtimes, and the PR does not show one that needs this. The code-judo move is to revert `parseFormData` to its single `formData()` call and keep only the guard change, which deletes the cast, the duplicate header lookup, the duplicated sequence, and the test churn. If a runtime truly needs buffering, give the FormData-with-cache operation one owner that both parseBody and the validator call. Full evidence: `01_body-and-buffer.md`, Finding A.
Consequence: —
Fix: —

### Item 2
Location: src/utils/buffer.ts:112
Claim: **2. Media-type normalization is implemented three different ways, and `bufferToFormData` now silently rewrites its input (src/utils/body.ts:104, src/utils/buffer.ts:112, src/validator/validator.ts:24-26).** parseBody uses `split(';')[0].trim().toLowerCase()` with equality, buffer.ts uses `replace(/^[^;]+/, ...)` which does not trim, and the validator uses `/i` regexes with their own parameter rules. These already differ in edge cases (whitespace handling, which parameters are accepted), and the PR widens the divergence instead of consolidating it. Putting a regex-based Content-Type rewrite into a generic bytes-to-FormData utility is hidden behavior in the wrong layer, and given the Node probe it is probably redundant. Recommended: introduce a single `getMediaType()` helper, use it in parseBody (and have the validator guard reuse it where it only needs the type), and remove the `buffer.ts` change unless a failing runtime is demonstrated. Full evidence: `01_body-and-buffer.md`, Finding B.
Consequence: —
Fix: —

### Item 3
Location: src/utils/body.test.ts
Claim: **3. Minor: duplicated test setup and a test for probably-dead code.** The "generate multipart, replace header casing, resend buffer" setup is repeated in body.test.ts and validator.test.ts, and the new buffer test protects the normalization described in finding 2. Low priority; resolved automatically if findings 1 and 2 are taken. See `02_validator-and-tests.md`.
Consequence: —
Fix: —
