# Review blind-a9f6ef

### Item 1
Location: crates/core/flags/complete/rg.zsh:441
Claim: When compinit has not run yet, the `! $+functions[compdef]` branch calls `_rg "$@"` outside a completion context, so the script errors and registers nothing.
Consequence: A user puts `source <(rg --generate complete-zsh)` in .zshrc above `compinit`, which is a common ordering. `compdef` is undefined, so the script runs `_rg` directly and prints `_rg:341: command not found: _arguments` (I reproduced this in zsh). It prints this on every shell start, and `rg` is never registered with `compdef`. The `|| (( ! $+functions[compdef] ))` clause was added only to satisfy ci/test-complete. Its fallback is the same failure as issue #2956. A better approach is to make the CI path explicit, for example by testing `$_RG_COMPLETE_LIST_ARGS`, and to skip `_rg` silently or defer registration when `compdef` is missing.
Fix: —

### Item 2
Location: FAQ.md:134
Claim: The `source <(...)` snippet is written as a shell prompt (`$ source ...`) even though the text says to add it to ~/.zshrc.
Consequence: A user copies the line into .zshrc with the leading `$ ` and gets `command not found: $`. The line is a file entry, not an interactive command, so it should have no `$ ` prefix.
Fix: —

### Item 3
Location: FAQ.md:134
Claim: The FAQ does not say that the `source <(rg --generate complete-zsh)` method only works after `compinit` has run.
Consequence: A user adds the line near the top of .zshrc, before `autoload -U compinit && compinit`. The script then fails with `_arguments: command not found` (see the rg.zsh finding) and completion is not registered. The doc never says the line must come after `compinit`. The fpath instructions also never say the `fpath=(...)` line must come before `compinit`.
Fix: —

### Item 4
Location: FAQ.md:138
Claim: The performance note is ungrammatical and unquantified.
Consequence: The sentence "while this approach is easier to setup, is generally slower than the previous method" is missing its subject. "Setup" is also used as a verb where "set up" is correct. The claim of added shell-startup time has no number; the PR discussion measured about 4ms. Readers cannot judge whether it matters.
Fix: —

### Item 5
Location: crates/core/flags/complete/rg.zsh:441
Claim: The `$funcstack[1]` check assumes zsh-native 1-based array indexing and breaks when the user has `ksh_arrays` set.
Consequence: A user who sources the script with `setopt ksh_arrays` active gets `./rg.zsh:441: bad output format specification` (I reproduced this in zsh). With ksh_arrays, `$funcstack[1]` is the second stack entry, so the check tests the wrong element and the branch choice is unreliable. Using `${funcstack[1]}`, or wrapping the check in `emulate -L zsh`, avoids this.
Fix: —

### Item 6
Location: crates/core/flags/complete/rg.zsh:437
Claim: The new comment and branch logic are misleading and the branches are not mutually clear.
Consequence: The comment says "Don't run the completion function when being sourced by itself". The code actually runs `_rg` whenever `compdef` is missing, which includes some sourcing cases. A maintainer reading it will assume sourcing never calls `_rg`. The condition also couples production behaviour to the CI harness, which relies on `compdef` being absent. If the CI environment ever loads compinit, ci/test-complete would hit `compdef _rg rg` and get no `_arguments` dump.
Fix: —

### Item 7
Location: FAQ.md:116
Claim: The FAQ now says the file-plus-fpath method is "recommended", but the stated fpath instruction is incomplete.
Consequence: The added `fpath=($HOME/.zsh-complete $fpath)` text does not say it must run before `compinit`, or that `compinit` must be loaded at all. A user who appends it after `compinit` finds that completion does nothing until `compinit` is re-run or a new shell is started.
Fix: —
