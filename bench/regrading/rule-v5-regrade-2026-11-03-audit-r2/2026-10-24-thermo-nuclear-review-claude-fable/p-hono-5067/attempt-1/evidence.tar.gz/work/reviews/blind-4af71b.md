# Review blind-4af71b

### Item 1
Location: src/utils/body.ts:125-132
Claim: ## Finding 1 — High: `parseBody()` after `c.req.formData()` now throws (multipart) or returns garbage (urlencoded)

**File/lines:** `src/utils/body.ts:125-132` (new `parseFormData` body), in combination with the existing `HonoRequest.#cachedBody` at `src/request.ts:220-239`.

**Evidence traced.** Before this PR, `parseFormData()` called `(request as Request).formData()`. For a `HonoRequest` that resolves to `HonoRequest.formData()` → `#cachedBody('formData')`, which returns the already-cached `FormData` promise if `c.req.formData()` had been called earlier. After this PR, `parseFormData()` unconditionally calls `(request as Request).arrayBuffer()` → `#cachedBody('arrayBuffer')`. When `bodyCache.arrayBuffer` is empty but `bodyCache.formData` is populated (because `c.req.formData()` ran first), `#cachedBody` falls into its "any cached key" branch and does `new Response(formData).arrayBuffer()`. That re-serializes the `FormData` as a brand-new multipart document with a freshly generated boundary (`------formdata-undici-…`). `parseFormData()` then passes those bytes to `bufferToFormData(arrayBuffer, headers.get('Content-Type'))`, i.e. parses them under the *original* request Content-Type:

- Original `multipart/form-data; boundary=<old>` → the new body does not contain `<old>` → undici throws `TypeError: Failed to parse body as FormData` (`no boundary found in multipart body`). `parseBody()` rejects and an app handler returns `500 Internal Server Error`.
- Original `application/x-www-form-urlencoded` → the multipart bytes are parsed as a URL-encoded string → `parseBody()` resolves successfully with a garbage object such as `{"------formdata-undici-0943…\r\nContent-Disposition: form-data; name": "\"message\"\r\n\r\nhello\r\n------formdata-undici-0943…--\r\n"}`. No error is raised; the handler silently receives wrong data.

Additionally, line 130 overwrites `request.bodyCache.formData` with the new (rejected) promise before awaiting it, so after one failed `parseBody()` a subsequent `c.req.formData()` — which used to work — also throws.

I verified this by bundling a scratch script against the head and against the merge-base source tree (extracted with `git archive main src`, clone untouched):

```
# head (5226d41)
multipart:  formData() then parseBody()              -> THREW: Failed to parse body as FormData.
urlencoded: formData() then parseBody()              -> {"------formdata-undici-0943…\r\nContent-Disposition: form-data; name":"\"message\"\r\n\r\nhello\r\n…"}
multipart:  formData(), parseBody(), formData() again -> THREW: Failed to parse body as FormData.
app: middleware c.req.formData() → handler c.req.parseBody() (multipart)  -> 500 Internal Server Error
app: middleware c.req.formData() → handler c.req.parseBody() (urlencoded) -> 200 with garbage body

# merge-base (9728702)
multipart:  formData() then parseBody()              -> {"message":"hello"}
urlencoded: formData() then parseBody()              -> {"message":"hello"}
multipart:  formData(), parseBody(), formData() again -> {"firstGet":"hello","secondGet":"hello"}
app: middleware formData() → handler parseBody() (multipart)  -> 200 {"message":"hello"}
app: middleware formData() → handler parseBody() (urlencoded) -> 200 {"message":"hello"}
```

Orderings that still work on the head (verified): `parseBody()` → `formData()`/`text()`, `parseBody()` twice, `blob()` → `parseBody()`, `arrayBuffer()` → `parseBody()`, and `validator('form')` → `parseBody()` (the validator caches `arrayBuffer` first, so the new code finds the original bytes). Some orderings actually improve (`text()` → `parseBody()` and `arrayBuffer()` → `parseBody()` used to throw and now work), but that does not offset breaking the previously supported `formData()` → `parseBody()` order.

**Failure it causes.** Any application where `c.req.formData()` is consumed before `c.req.parseBody()` on the same request — e.g. a middleware (auth/CSRF/logging) that reads a form field via `c.req.formData()` and a handler that later calls `c.req.parseBody()`, or a handler that uses both APIs — regresses from working to either a 500 (multipart) or silently corrupted parsed data (urlencoded). This is a public, documented API (`c.req.parseBody()`), and the urlencoded case fails without any error, which is why I rate it High rather than Medium. It is a correctness/compat regression, not a security vulnerability. No new test exercises this ordering, so CI does not catch it.

**Suggested direction (not applied).** Mirror the validator's logic: in `parseFormData()`, if `request instanceof HonoRequest && request.bodyCache.formData` is set, `await` that cached value instead of re-reading `arrayBuffer()`; only fall through to `arrayBuffer()` + `bufferToFormData()` when no `formData` is cached. Add a regression test for `formData()` followed by `parseBody()` for both media types.
Consequence: —
Fix: —
