# Review blind-50696e

### Item 1
Location: src/requests/adapters.py:75-110
Claim: **1. The shared module-level `SSLContext` is passed to urllib3 together with client-certificate arguments, so urllib3 loads the client cert into the global context** (`src/requests/adapters.py:75-78` and `:94-110`). `_urllib3_request_context()` sets `pool_kwargs["ssl_context"] = _preloaded_ssl_context` for every `verify=True` request and then, a few lines later, still adds `cert_file` and `key_file` when `cert=` is given. Inside urllib3 (`connection._ssl_wrap_socket_and_match_hostname` then `util.ssl_.ssl_wrap_socket`), a caller-supplied context is used as is and `context.load_cert_chain(certfile, keyfile)` is then run on it, followed by `set_alpn_protocols`. So after one `requests.get(url, cert=("a.pem", "a.key"))` the process-wide default context permanently holds that client identity, and every later `verify=True` request to any host, including requests with no `cert=`, can present it if the server asks for a client certificate. A second request with a different `cert=` stacks another chain onto the same object. The reviewer confirmed with a probe that the same context object is placed in `pool_kwargs` whether or not a client cert is passed. The leak is read from urllib3 2.8.0's source rather than observed end to end over a TLS connection. The PR discussion only considered the context's thread safety. Tiran's caveat that nothing should reconfigure a context once connections use it is violated by the PR's own code path. Remedy: only use the shared context when `client_cert is None`, or make the shared object a template and hand urllib3 a cheap per-pool copy. See the detail file for a worked proposal. At minimum, a regression test should assert that the shared context is untouched after a `cert=` request.
Consequence: —
Fix: —

### Item 2
Location: src/requests/adapters.py:94-317
Claim: **2. CA-selection logic now lives in two places that must stay in sync, and the diff adds a second `isdir` branching tree instead of deleting the first** (`adapters.py:94-100` and `:297-317`). Before the PR, `cert_verify()` was the single place that decided between the default bundle, a file and a directory. After it, `_urllib3_request_context()` decides file versus directory for `verify` strings (`ca_certs` versus `ca_cert_dir`) and `cert_verify()` repeats the same `os.path.isdir` split to set `conn.ca_certs` or `conn.ca_cert_dir` on the connection. For string `verify`, urllib3 therefore receives the CA path twice, once through pool kwargs and once through connection attributes. The PR author said as much in the description: setting the attributes in `cert_verify()` may no longer be needed. That is the code-judo move the PR stops short of. Make `_urllib3_request_context()` the sole owner of trust-store selection, including the existence check that currently raises `OSError` in `cert_verify()`. Then `cert_verify()` shrinks to setting `CERT_NONE` for the unverified case and validating the client cert. The new `elif verify is True` / `elif isinstance(verify, str)` / nested `if not isdir ... else` chain in `_urllib3_request_context()` also reads worse than a small `_ca_pool_kwargs(verify)` helper that returns a dict and can be unit tested without a request object.
Consequence: —
Fix: —

### Item 3
Location: src/requests/adapters.py:75-78
Claim: **3. Module-level work at import time, with a lost error path** (`adapters.py:75-78`). `_preloaded_ssl_context = create_urllib3_context()` plus `load_verify_locations(extract_zipped_paths(DEFAULT_CA_BUNDLE_PATH))` now runs on every `import requests`. That includes users who only ever use `verify=False` or custom bundles, and it is exactly the multi-millisecond OpenSSL call the PR is trying to take off the hot path, now moved onto the import path. It also performs zip-extraction of the bundle to a temp file at import time. A missing or broken certifi bundle used to surface as the clear `OSError("Could not find a suitable TLS CA certificate bundle ...")` at request time. It now surfaces as a bare `ssl`/`FileNotFoundError` while importing `requests`, which also takes down `requests.exceptions` consumers. The existence check was dropped for the `verify=True` path altogether. Remedy: build the context lazily behind a `functools.lru_cache`d `_default_ssl_context()`, called from the `verify is True` branch, and keep the friendly error there. Combined with finding 1, a lazy factory is also the natural place to return a fresh or copied context when client certs are involved.
Consequence: —
Fix: —

### Item 4
Location: src/requests/adapters.py:297-307
Claim: **4. `cert_verify()` is no longer self-sufficient, and the new invariant is carried only by a comment** (`adapters.py:297-307`). The public-but-subclass-oriented `cert_verify(conn, url, verify, cert)` used to guarantee that the connection ended up with usable CA settings for `verify=True`. It now silently relies on the caller having built the pool through `_urllib3_request_context()` with the preloaded context, and says so in a four-line comment. Any adapter subclass that overrides `_get_connection` or `init_poolmanager`, or that calls `cert_verify` on a connection from a different pool, gets `CERT_REQUIRED` with no CA source, which falls through to urllib3's `load_default_certs()` and therefore the OS trust store instead of certifi. That is a silent change of trust anchors. The `verify` docstring still describes the old contract. Making finding 2's single owner explicit would remove the implicit coupling.
Consequence: —
Fix: —

### Item 5
Location: src/requests/adapters.py:297-317
Claim: **5. Small legibility and typing points in the rewritten `cert_verify()`** (`adapters.py:297-317`). `cert_loc = verify` is a pointless alias whose comment ("`verify` must be a str with a path then") documents an unchecked assumption, because the signature admits `None` and `bool` too. The block now nests four deep (`if https and verify` / `if verify is not True` / `if not isdir` / ...) and the new comment lines exceed the project's wrapping. This is a nit, but it disappears with finding 2.
Consequence: —
Fix: —

### Item 6
Location: (no file)
Claim: **6. No test covers the new contract.** The PR changes which `SSLContext` each pool uses and what is loaded into it, yet adds no test. The author said they could not find a way to inspect it. In fact `_urllib3_request_context()` is a module-level pure function, and `HTTPAdapter._get_connection()` returns the pool, whose `ssl_context` and key are inspectable. A test could assert reuse of one pool across requests, that `verify=False` and string-`verify` requests do not use the shared context, and that the shared context is unchanged after a `cert=` request (finding 1).
Consequence: —
Fix: —
