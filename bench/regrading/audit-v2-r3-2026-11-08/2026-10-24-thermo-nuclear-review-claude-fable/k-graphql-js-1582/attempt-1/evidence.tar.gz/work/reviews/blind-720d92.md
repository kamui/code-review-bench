# Review blind-720d92

### Item 1
Location: src/error/__tests__/GraphQLError-test.js:57-64
Claim: ### [Low] `creates new stack if original error has no stack` no longer exercises the stackless-original path

**File:** `src/error/__tests__/GraphQLError-test.js:57-64` (diff hunk replacing `{ message: 'original' }` with `new Error('original')` at line 58).

**Evidence:** Before this change the test passed a plain object `{ message: 'original' }` as `originalError`. A plain object has no `stack` property (verified: `({message:'original'}).stack === undefined`), so `GraphQLError.js:195` (`originalError && originalError.stack`) was false and the constructor fell through to the `Error.captureStackTrace` branch at `GraphQLError.js:201`, which is the behaviour the test title describes. The change substitutes `new Error('original')`, whose `.stack` is always a string in V8 (verified). With that input line 195 is true and the error simply adopts `original.stack`, which is exactly what the preceding test `uses the stack of an original error` (lines 41-55) already asserts. The two tests are now equivalent except for `null` versus `undefined` placeholders; the assertions still pass, so mocha cannot detect the loss.

**Failure it causes:** The code path "an `originalError` was supplied but carries no `stack`" is no longer covered by any test. A future regression on `GraphQLError.js:195-209` (for example, a refactor that unconditionally copies `originalError.stack`, leaving `e.stack` undefined when the original is stackless) would not be caught, even though a test whose name promises precisely that guarantee continues to pass. This is a silent test-coverage regression introduced by the typing migration, not a runtime defect. A typed alternative that preserves the original intent is `const original: any = { message: 'original' };` or deleting `stack` from a real `Error` before passing it.
Consequence: —
Fix: —
