# Review blind-dcffd2

### Item 1
Location: FAQ.md:135
Claim: Document that compinit must run before sourcing the completion
Consequence: When this command is sourced before compinit has defined compdef, the new branch in rg.zsh calls _rg directly. Outside a completion invocation, _rg reaches _arguments and emits the same 'can only be called from completion function' error reported by the issue. A plain zsh setup without an earlier compinit therefore still cannot use the advertised startup-file snippet.
Fix: State that the zsh completion system must be initialized before this command, and show the command after compinit in the .zshrc example.
