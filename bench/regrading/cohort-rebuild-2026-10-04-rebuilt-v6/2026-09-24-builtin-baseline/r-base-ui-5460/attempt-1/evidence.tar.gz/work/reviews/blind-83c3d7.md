# Review blind-83c3d7

### Item 1
Location: packages/react/src/field/control/FieldControl.tsx:106
Claim: A controlled `value={null}` makes `isControlled` true, so `onChange` returns early, but `serializedValue` is undefined, so `useValueChanged` skips the sync. No path updates filled, dirty, errors or validation for that value.
Consequence: Confirmed with a scratch test. A consumer maps empty input to null (`onValueChange={(v) => setValue(v || null)}`), which is common with form libraries. The user clears the field and the value becomes null. `data-filled` stays set, errors are not cleared, and a required field is not re-validated. Before this PR, `onChange` always updated this state.
Fix: —

### Item 2
Location: packages/react/src/field/control/FieldControl.tsx:142
Claim: Controlled mode now returns before the `defaultPrevented` guard (the react#9023 workaround). The layout effect then runs `clearErrors` and `validation.change` even when the input event was prevented.
Consequence: Confirmed. Setup: `<Form errors={{message:'Server error'}}>` with a controlled `Field.Control`, and an input listener that calls `preventDefault()`. `onValueChange` still fires, the consumer sets the value, and `useValueChanged` clears the 'Server error' message and validates. The existing test 'does not clear errors or validate when change is prevented' only covers uncontrolled mode.
Fix: —

### Item 3
Location: packages/react/src/field/control/FieldControl.tsx:148
Claim: `details.cancel()` still does not stop internal handling as the PR claims. `setDirty` and `setFilled` run before the `isCanceled` check, so only clearErrors and validation are skipped.
Consequence: Confirmed. With an uncontrolled `<Field.Control onValueChange={(v, d) => d.cancel()} />`, typing 'a' still sets `data-dirty` and `data-filled` on Field.Root. The new cancel test only checks that `validate` was not called.
Fix: —

### Item 4
Location: packages/react/src/field/control/FieldControl.tsx:111
Claim: A programmatic reset now runs `validation.change` unconditionally. In onChange mode, resetting a required field to its empty initial value immediately marks it invalid while it reads as pristine.
Consequence: Confirmed. Setup: `validationMode="onChange"`, a required controlled control, the user types 'x', then a reset button calls `setValue('')`. The root ends with `data-invalid` set and no `data-dirty`, so the form shows a 'required' error right after the reset. `markedDirtyRef` is never cleared when dirty returns to false. This is the form-library reset case the PR set out to fix.
Fix: —

### Item 5
Location: packages/react/src/field/control/FieldControl.tsx:92
Claim: Passing the stringified value to `useRegisterFieldControl` changes what the Field `validate` function receives on submit. A non-string controlled value now arrives as a string instead of its original type.
Consequence: Confirmed. With a controlled `value={5}` and `Field.Root validate={fn}`, submitting the Form calls `validate("5", {n: "5"})`. Before, the form's `validate` used `registration.value` and passed the number 5. Validators that check `typeof v === 'number'` or compare arrays break silently. `validityData.initialValue` and `validityData.value` also become strings.
Fix: —

### Item 6
Location: packages/react/src/field/control/FieldControl.tsx:99
Claim: The mount-time filled effect only ever sets filled to true and never re-runs. The old branch that set filled to false for a controlled `''` was removed, and nothing replaces it when a controlled value becomes null or undefined.
Consequence: A controlled value goes from 'abc' to undefined or null, for example a form library clearing a field by setting undefined. `useValueChanged` returns early, so `data-filled` stays true while the input is empty.
Fix: —

### Item 7
Location: packages/react/src/field/control/FieldControl.tsx:142
Claim: In controlled mode, cancel and preventDefault are ignored for field state, because state now follows the `value` prop no matter what the event handler decided.
Consequence: A consumer calls `details.cancel()` (or the event was prevented) but still updates its controlled state, as a pass-through wrapper does. Field still clears errors and validates, so the cancel fix only applies in uncontrolled mode. The docs describe `onValueChange` as 'Use when controlled'.
Fix: —

### Item 8
Location: packages/react/src/field/control/FieldControl.tsx:105
Claim: Controlled validation moved from the change handler into a layout effect, which adds a second synchronous render on every keystroke in onChange mode.
Consequence: Every keystroke in a controlled onChange-mode Field.Control now renders the Field subtree twice, including a blocking layout-effect `setValidityData`. The PR's own table shows this, and the CI benchmark reported regressions around 12%. An alternative that keeps one render: run validation in `onChange` when the value the consumer commits equals `inputValue`.
Fix: —

### Item 9
Location: packages/react/src/field/control/FieldControl.tsx:111
Claim: The dirty, filled, clearErrors and validation sequence is copied between the `useValueChanged` callback and the uncontrolled `onChange` branch, with small differences in ordering and guards.
Consequence: The two copies have already drifted. `clearErrors` runs before `setDirty` in one and after in the other, and only one is guarded by cancel and preventDefault. A shared `syncFieldState(value)` helper would keep the two modes consistent.
Fix: —

### Item 10
Location: packages/react/src/field/control/FieldControl.test.tsx:47
Claim: The test name and comment say 'renders once per keystroke', but the test only covers the default onSubmit mode. The onChange mode, which the PR says costs two renders, has no assertion.
Consequence: A future change that adds renders in onChange mode, or breaks it, passes unnoticed. The name also suggests one render per keystroke in every mode, which the PR body contradicts.
Fix: —
