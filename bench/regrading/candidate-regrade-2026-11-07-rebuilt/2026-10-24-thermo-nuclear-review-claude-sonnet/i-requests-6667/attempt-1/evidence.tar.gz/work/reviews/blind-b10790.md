# Review blind-b10790

### Item 1
Location: src/requests/adapters.py:75-95
Claim: ## Finding 1 (High): the shared module-level SSLContext is mutated by client certificates, so one request's mTLS identity leaks into other pools, hosts and sessions

**Where:** `src/requests/adapters.py:75-78` (the `_preloaded_ssl_context` global) and `src/requests/adapters.py:94-95` (`pool_kwargs["ssl_context"] = _preloaded_ssl_context` for every `verify=True` request).

**Evidence traced:**
- `_urllib3_request_context` always attaches the single process-wide context when `verify is True`. It does this whether or not a client cert is also given. In the same function, `cert_file` and `key_file` are still added to `pool_kwargs` for a `cert=` argument.
- I ran `_get_connection` against `https://example.com` twice, once with `cert=("/tmp/c.pem","/tmp/k.pem")` and once with `cert=None`. The two calls return different pools, because the pool key includes the cert file. Both pools carry the same `_preloaded_ssl_context` object (`True True False` for ctx-is-shared, ctx-is-shared, same-pool).
- In urllib3 2.8.0, `util/ssl_.py:ssl_wrap_socket` (lines ~429-433) runs `context.load_cert_chain(certfile, keyfile[, key_password])` directly on the `ssl_context` it is given. Before this PR, urllib3 built a fresh context for each pool, so that call only touched a per-pool object. Now it modifies the process-global object.
- `connection.py:_ssl_wrap_socket_and_match_hostname` (~line 1042) also sets `context.verify_mode` on the supplied context. It sets `check_hostname = False` for `assert_hostname` or `assert_fingerprint`.
- `SSLContext.load_cert_chain` has no per-connection scope. After it is called once, every later handshake made with that context (to any host, from any Session or thread) will offer that client certificate if the server sends a CertificateRequest. Calling it again replaces the earlier chain.

**Failure it causes:**
1. Sensitive, security-relevant behaviour: Session A calls `get("https://internal.corp", cert=("alice.pem","alice.key"))`. Afterwards, an unrelated `requests.get("https://other-service.example")`, with no `cert`, in the same process presents alice's certificate to that server. This discloses the identity and certificate, and may authenticate the unrelated request as alice. It can also cross tenant boundaries in multi-tenant services that use per-tenant client certs.
2. Correctness and race: two threads using `cert=A` and `cert=B` with `verify=True` concurrently call `load_cert_chain` on the same context. The later call can overwrite the earlier one between loading and handshake, so a request can authenticate with the other tenant's certificate. Requests without `cert` can no longer be relied on to be anonymous.
3. If one request's key is encrypted or its cert is bad, `load_cert_chain` can fail or half-update the shared state, which may affect later requests.

The maintainer discussion considered thread-safety of reading the context. It did not consider this per-request mutation by urllib3. The commit message's premise, "SSLContext is shared safely as long as it is not reconfigured once used by a connection", is violated by urllib3 itself whenever `cert=` is passed.

**Suggested direction:** do not share the context when `client_cert` is set (fall back to the old per-pool path), or give each distinct cert its own cached copy of the context.
Consequence: —
Fix: —

### Item 2
Location: src/requests/adapters.py:75-78
Claim: ## Finding 2 (Medium): CA bundle is now loaded at `import requests.adapters` time, so a missing or unreadable bundle makes `import requests` fail

**Where:** `src/requests/adapters.py:75-78`; the removed check was in `cert_verify`.

**Evidence traced:**
- The module-level call does `create_urllib3_context()`, then `load_verify_locations(extract_zipped_paths(DEFAULT_CA_BUNDLE_PATH))`, at import time. The old code did this lazily per request inside `cert_verify`.
- The old code checked `os.path.exists(cert_loc)` and raised `OSError("Could not find a suitable TLS CA certificate bundle, invalid path: ...")` only at request time. That check is deleted for `verify=True`. Any failure now surfaces as an uncaught `FileNotFoundError`, `ssl.SSLError` or similar from `import requests`.
- `extract_zipped_paths` writes the bundle to a temp directory as a side effect. It now runs on every import, even for programs that never make an HTTPS request or that use `verify=False` or a custom bundle. This affects zipapp, PyInstaller and pants users, who are exactly the case raised in review.

**Failure it causes:**
- Distro-patched or stripped certifi, containers with a missing bundle, and read-only or unwritable temp dirs in zipapps all turn into a hard import failure for the whole library. Previously these environments could still use `verify=False` or `verify="/custom/ca.pem"`.
- Import latency increases, since loading roughly 140 KB of PEM is the slow call this PR sets out to avoid.
Consequence: —
Fix: —

### Item 3
Location: src/requests/adapters.py:75-95
Claim: ## Finding 3 (Low): the default trust store is frozen at import and no longer follows runtime changes

**Where:** `src/requests/adapters.py:75-78`, `94-95`.

**Evidence traced:** the old `cert_verify` re-read `DEFAULT_CA_BUNDLE_PATH` (via `requests.adapters`'s imported name) and the bundle file on every request. Now the context is built once.

**Failure it causes:**
- A long-running process that gets a refreshed certifi or system bundle file on disk (rotation, a revoked root removed) keeps trusting the old roots until restart.
- Code or tests that monkeypatch `requests.adapters.DEFAULT_CA_BUNDLE_PATH` or `certs.where` after import silently have no effect on `verify=True`.
- Custom adapter subclasses that call `cert_verify()` without going through `_get_connection` (the legacy `get_connection` path) used to get `conn.ca_certs` set to certifi for `verify=True`. They now get no explicit CA, so urllib3 falls back to `load_default_certs()` (the OS store) rather than the certifi bundle.
Consequence: —
Fix: —
