# Review blind-593b53

### Item 1
Location: FAQ.md:131-135
Claim: In `FAQ.md:131–135`, the text instructs users to add the following code to `.zshrc`, but line 135 starts with a literal `$`: `$ source <(rg --generate complete-zsh)`. Copied into the startup file as directed, zsh tries to execute a command named `$`, returns status 127 with `command not found: $`, and never sources or registers the completion. This is an executable configuration example, unlike the earlier interactive command transcripts. Remove the leading `$` so the snippet reads `source <(rg --generate complete-zsh)`, consistent with the preceding prompt-free `fpath` configuration example.

The failure was reproduced with the head completion fixture and an initialized
completion system; the corrected command registered `_rg` successfully.
Full evidence and the worked remedy are in [02_faq.md](02_faq.md).
Consequence: —
Fix: —

### Item 2
Location: FAQ.md:124-135
Claim: In `FAQ.md:124–135`, both new `.zshrc` instructions omit their dependency on the position of `compinit`. The directory method must extend `fpath` before the existing `compinit` call scans completion files, while the dynamic method must source the script after that call has defined `compdef`. Adding the directory at the end of a startup file that already ran `compinit` leaves `rg` unregistered; sourcing before initialization reaches the compatibility fallback in `rg.zsh:441–442` and fails with `command not found: _arguments`. Both failures were reproduced in a shell without another installed `_rg` completion. State the ordering next to each method, and show completion initialization for users whose startup file does not already perform it. Keep the test-compatible fallback in the completion script; fix the installation contract in the FAQ.

Both correct orderings registered `rg` to `_rg` in the same isolated fixture.
Full evidence and worked startup layouts are in [02_faq.md](02_faq.md).
Consequence: —
Fix: —
