# Review blind-ade63f

### Item 1
Location: clientconn.go:986
Claim: updateAddrs now returns with ac.mu still locked, because it hands the lock to a goroutine that has not started yet. The deferred ac.transport.GracefulClose() therefore runs while ac.mu is held, which breaks the reason it was deferred ('GracefulClose => onClose, which requires locking ac.mu').
Consequence: The subchannel is Ready and the balancer calls UpdateAddresses with a list that does not contain curAddr. updateAddrs runs `go ac.resetTransportAndUnlock()` and returns, and the deferred GracefulClose runs. GracefulClose takes t.mu and calls t.onClose, and onClose's ac.mu.Lock() blocks until the new goroutine is scheduled, sets Connecting and unlocks. During that time the balancer serializer goroutine is stuck inside UpdateAddresses and the transport's t.mu is held. Anything that touches t.mu, such as the reader loop, keepalive or stream creation, is also blocked. It is not a permanent deadlock today, but it depends on nothing in resetTransportAndUnlock's locked prefix ever needing t.mu or the serializer to make progress.
Fix: —

### Item 2
Location: clientconn.go:996
Claim: The mutex is locked in one goroutine and unlocked in another (`go ac.resetTransportAndUnlock()`). While the goroutine waits to be scheduled, ac.mu is held by no running code, and the struct comment says this mutex is on the RPC path and its use 'should be minimized'.
Consequence: Under a heavily loaded scheduler, for example with many subchannels getting address updates at once, every RPC calling ac.getReadyTransport/getTransport, every channelz query and every tearDown on this addrConn blocks until the runtime schedules the new goroutine. That adds latency to unrelated RPCs. A future edit that adds an early return or panic between the Lock in updateAddrs and the goroutine start would leave ac.mu locked forever with no owner.
Fix: —

### Item 3
Location: clientconn.go:990
Claim: When updateAddrs gets an empty address list while Connecting or Ready, it sets Idle and then immediately starts resetTransportAndUnlock. That sets Connecting and calls tryAllAddrs with zero addresses, which returns a nil error, so the attempt counts as a success and the subchannel stays Connecting forever with no transport.
Consequence: A custom LB policy calls SubConn.UpdateAddresses(nil) on a Ready subconn. The state goes Idle, then Connecting. tryAllAddrs returns firstConnErr == nil, so the success path resets backoffIdx and returns. No transport is ever created and nothing moves the state to TransientFailure or Idle, so RPCs picked to this subconn hang in getTransport until their deadline. The function is touched by this PR but this path is not fixed.
Fix: —

### Item 4
Location: clientconn.go:983
Claim: The comment justifying the deferred GracefulClose is now wrong. The defer no longer runs after ac.mu is released, because the lock is handed to the goroutine rather than unlocked here.
Consequence: A maintainer who trusts the comment will assume onClose can take ac.mu straight away when the deferred call runs. Code that relies on that, such as waiting on something set by onClose inside updateAddrs's caller, would deadlock or stall behind the handoff goroutine.
Fix: —

### Item 5
Location: clientconn.go:1234
Claim: The fix works by handing a locked mutex to another function and, in updateAddrs, to another goroutine. The simpler root-cause fix is to move the Idle-to-Connecting transition, plus the capture of ctx, addrs and backoff, into connect()/updateAddrs while they hold the lock, and have the connection attempt take those values as arguments without re-checking state.
Consequence: Handing a lock across goroutines is fragile. The race detector cannot flag a missing Unlock on some early-return path added later, and reviewers already raised the lack of enforcement in thread #11. If connect/updateAddrs set Connecting and snapshotted the parameters under their own lock (the fix first proposed in the issue), the attempt could run with no lock handoff and updateAddrs could unlock before its deferred GracefulClose, as it did before.
Fix: —

### Item 6
Location: clientconn.go:922
Claim: No regression test was added for the concurrent connect() race. The only evidence is that the xds Test/AuthorityRevive flake (0.4%) went away.
Consequence: A future refactor could bring back the gap between the Idle check in connect() and the transition to Connecting. For example, it could move the Unlock back or split resetTransportAndUnlock. Two concurrent acbw.Connect() calls (each runs `go ac.connect()`) would then both run tryAllAddrs, and one transport would be orphaned until the channel closes. No core-package test would catch this, only a rare xds flake.
Fix: —

### Item 7
Location: clientconn.go:1236
Claim: resetTransportAndUnlock's early return on acCtx.Err() leaves the addrConn in its current state without logging. In connect() it now runs under the same critical section as the Idle check, but a canceled ctx with a non-Shutdown state is still silently ignored.
Consequence: tearDown or updateAddrs cancels ac.ctx, but connect() runs before the state becomes Shutdown, or an ac.cc.ctx cancellation propagates while the state is still Idle. connect() returns nil, the state stays Idle, and the balancer believes a connection attempt was started. Nothing records why no attempt happened, so a subconn stuck in Idle is hard to debug.
Fix: —

### Item 8
Location: test/goaway_test.go:271
Claim: Test log-ignore strings and error text still mention 'addrConn.resetTransport', which has been renamed to resetTransportAndUnlock. Those references are now stale.
Consequence: Anyone grepping for resetTransport while debugging these tests finds references to a function that no longer exists. The same applies to test/end2end_test.go:3597 and :3637, which add to the confusion around the lock-handoff contract.
Fix: —
