# Shared eligibility decisions

Use these pinned decisions for explicitly matched items. Pending claims remain unresolved.
Eligibility does not prove an item's recovery or fix sufficiency. If the item describes a different trigger, mechanism or consequence, stop for a corrected match rather than override the decision.
