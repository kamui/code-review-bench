# Review blind-38cec7

### Item 1
Location: crates/core/flags/complete/rg.zsh:441-445
Claim: **1. The `compdef` probe stands in for "the test harness" and turns the new feature's main failure mode back into the original error** (`crates/core/flags/complete/rg.zsh:441-445`; detail in `01_zsh_completion_entrypoint.md`, verified by execution). The condition `[[ $funcstack[1] == _rg ]] || (( ! $+functions[compdef] ))` mixes two unrelated meanings. The first clause is the legitimate "I was autoloaded as a completion function" check. The second exists, per the PR thread, because `ci/test-complete` sources the file with no completion system loaded and needs `_rg` to run so it can dump the `_arguments` specs. A missing `compdef` is a proxy for "test harness", but it is equally true for a real user who has `source <(rg --generate complete-zsh)` in `.zshrc` before `compinit`. In that case the script calls `_rg` outside completion and dies with `_rg:341: command not found: _arguments`. That is the same class of failure that issue #2956 reported, just with a different message. The branch that was meant to fix the issue is therefore silently dead for anyone whose ordering is wrong. The code-judo move is to make the harness explicit rather than inferred. The script already recognizes `_RG_COMPLETE_LIST_ARGS` in two places, so the entry condition can use it: run `_rg "$@"` when `$funcstack[1] == _rg` or when the dump variable is set, and otherwise register with `compdef`. Then the "no compdef" case becomes a real, separately handled condition (for example an explicit message, or a clean no-op), instead of falling into the completion body by accident. This removes the redundant third state that the PR author themselves described as "fine, but feels redundant".
Consequence: —
Fix: —

### Item 2
Location: crates/core/flags/complete/rg.zsh:441
Claim: **2. With the new logic, `ci/test-complete` dump mode is bypassed silently whenever a completion system is loaded** (`crates/core/flags/complete/rg.zsh:441` together with `:347`; detail in `01_zsh_completion_entrypoint.md`, verified by execution). I ran `( _RG_COMPLETE_LIST_ARGS=1 source ./rg.zsh )` in a shell after `compinit`. It printed nothing and exited 0. Without `compinit` it printed the argument specs. The CI script passes today only because it runs non-interactively without the completion system. Anyone who runs the script from a shell that has `compinit` loaded, or who later changes the script's prelude, gets an empty spec list. That would show up as every option missing rather than as a clear error. This is the same root cause as finding 1: the dump mode ought to be selected by its own variable, not by an environmental accident. The remedy is the same explicit `_RG_COMPLETE_LIST_ARGS` check. A stated invariant in the comment above the block would also help: "dump mode always runs `_rg`".
Consequence: —
Fix: —

### Item 3
Location: FAQ.md:124-139
Claim: **3. The FAQ never says that `compinit` has to run before the `source` line (and, for the `fpath` method, after the `fpath` assignment)** (`FAQ.md:124-139`; detail in `02_faq.md`). The new `source <(rg --generate complete-zsh)` recipe only works if `compdef` exists, which means `compinit` must already have run. I confirmed that sourcing before `compinit` fails. Users who drop the one-liner at the top of `.zshrc` will hit exactly that failure, and combined with finding 1 the error is not helpful. The `fpath` recipe has the mirror-image requirement: `fpath` must be set before `compinit`. Only the `fpath` assignment is mentioned. Add one sentence to each recipe, or a single shared sentence, about ordering relative to `compinit`.
Consequence: —
Fix: —

### Item 4
Location: FAQ.md:132-139
Claim: **4. The new FAQ paragraph is ungrammatical and the snippet has a stray prompt marker** (`FAQ.md:132-139`; detail in `02_faq.md`). The sentence reads "while this approach is easier to setup, is generally slower than the previous method". It has no subject for "is generally slower", and "setup" should be the verb form "set up". The `.zshrc` snippet is written as `$ source <(...)`, yet it is meant to be pasted into a file. The adjacent `fpath=(...)` snippet in the same section has no `$`, so the two are inconsistent, and a copied `$ ` would be a syntax error inside `.zshrc`. Fix the sentence and drop the `$`. The comparison in that sentence is fine, but it should say what the cost is (an `rg` process spawn and a re-parse of the ~450-line function on each shell start).
Consequence: —
Fix: —
