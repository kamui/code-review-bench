# Review blind-1fda5a

### Item 1
Location: packages/react/src/field/control/FieldControl.tsx:152
Claim: In uncontrolled mode `details.cancel()` only skips `clearErrors` and `validation.change`. `setDirty` and `setFilled` still run, so the cancel is only partly honoured.
Consequence: `<Field.Control onValueChange={(v, d) => d.cancel()} />` is uncontrolled. The user types 'a'. The DOM keeps 'a', and `data-dirty` and `data-filled` are set. Validation is skipped and stale errors are not cleared, so the field state disagrees with the validity state. The PR says cancel 'now stops the internal handling', but only the validation half stops. The new test only asserts that `validate` is not called, so it misses this.
Fix: —

### Item 2
Location: packages/react/src/field/control/FieldControl.tsx:145
Claim: The controlled path returns early from onChange and drops the `event.nativeEvent.defaultPrevented` guard. The value-change effect now runs `clearErrors` and `validation.change` even when the change event was prevented.
Consequence: A controlled Field.Control has a consumer that calls `event.preventDefault()` in its own `onChange`, which is the React issue 9023 workaround the guard exists for. The consumer also updates the value. Before this PR, validation and error clearing were skipped. Now the `useValueChanged` effect validates and clears errors anyway. The 'does not clear errors or validate when change is prevented' test covers only the uncontrolled case.
Fix: —

### Item 3
Location: packages/react/src/field/control/FieldControl.tsx:105
Claim: `useValueChanged` returns early when `serializedValue` becomes `undefined`, which happens when the value goes to `null` or `undefined`. Filled, dirty and validity are then left stale.
Consequence: A form-library reset sets the control's `value` from 'abc' to `null` or `undefined`. The input is cleared, or switches to uncontrolled. `data-filled` and `data-dirty` stay set, the error stays visible, and a pending async validator for 'abc' can still publish. This is the stale-state bug the PR set out to fix. The reset also does not sync from `undefined` back to a string, because the value ref then holds `undefined` and the effect only reads DOM state on mount.
Fix: —

### Item 4
Location: packages/react/src/field/control/FieldControl.tsx:101
Claim: The mount effect no longer clears `filled` for an empty controlled value. The old effect called `setFilled(false)` when `valueProp === ''`, and `useValueChanged` does nothing on first mount.
Consequence: `Field.Root` stays mounted while a `Field.Control` is conditionally unmounted and remounted with `value=''`. Root-level `filled` was left `true` by the previous control and is never reset. `data-filled` stays wrong until the user types.
Fix: —

### Item 5
Location: packages/react/src/field/control/FieldControl.tsx:105
Claim: Any controlled value change now marks the field dirty, sets `markedDirtyRef`, and runs validation, including async prefill and value normalisation, not just user input.
Consequence: A controlled field starts at '' and is later prefilled from fetched data. With `validationMode='onChange'` this fires `validate` on load. Because `markedDirtyRef` is now true, `valueMissing` and `required` errors are no longer suppressed. The user sees errors on a field they never touched. This matches sibling controls, but it is a behaviour change for existing Field.Control users. The PR body does not call it out, and no test covers it.
Fix: —

### Item 6
Location: packages/react/src/field/control/FieldControl.tsx:96
Claim: The registered baseline and value now use `String(value)`. An object or array value becomes '[object Object]' or 'a,b'. Two different arrays with the same joined string compare equal, and validation and form reads see coerced strings.
Consequence: A consumer passes an array or a value with a custom `toString` to Field.Control. The dirty check compares only the serialized strings, so ['a,b'] and ['a','b'] are indistinguishable. The value passed to `validate` changes from the DOM string to the serialized string. That is the same result for strings, but it is not documented for non-string values.
Fix: —

### Item 7
Location: packages/react/src/field/control/FieldControl.tsx:121
Claim: Moving the controlled sync into a layout effect costs one extra render per keystroke in `onChange` mode, and every controlled change now updates state in a second commit.
Consequence: A controlled Field.Control with `validationMode='onChange'` goes from 1 to 2 renders per keystroke, as the PR body admits. Large forms pay for it, and the bench report showed duration regressions elsewhere. A test asserts steady-state render counts only for the default onSubmit mode, so the onChange regression is not guarded.
Fix: —

### Item 8
Location: packages/react/src/field/control/FieldControl.test.tsx:130
Claim: There are no tests for the PR's other claims: a controlled value that the consumer rejects or rewrites, `details.cancel()` in controlled mode, array values, or a stale async validator on a programmatic change.
Consequence: The three behaviours listed above can regress without a failing test. Only the numeric dirty case and a programmatic set to 'external' are covered. Also, `renders once per keystroke` is misnamed, because the `onChange` case is 2 renders.
Fix: —

### Item 9
Location: packages/react/src/field/control/FieldControl.tsx:121
Claim: The `autoFocus` layout effect and the `inputRef` declaration were moved below the new hooks. This is unrelated churn that enlarges the diff and reorders the effects.
Consequence: Reviewers must check that reordering effects (register, filled, value-changed, autofocus) causes no timing change. It adds risk for no behavioural gain.
Fix: —
