# Review blind-6eeec9

### Item 1
Location: lib/batcher/batcher.go:267
Claim: Commit holds admitMu while blocking on `b.in <- ...`, which can block for a whole batch commit when the channel is full. Shutdown then blocks on admitMu.Lock() before it can close(b.closed).
Consequence: Size=N and the commit loop is inside a slow network commit(). N+1 concurrent Commits arrive, so one blocks on the full channel holding admitMu. The others queue on admitMu. Ctrl-C or fs-cache eviction calls Shutdown, which blocks on admitMu.Lock() until the loop drains. Before this change b.closed closed immediately and new Commits were rejected with 'batcher is shutting down'. Now Commits keep being admitted during the whole wait, so Shutdown is delayed, and after a signal the atexit handler can be slower to finish. Mutex fairness also lets already-queued Commits get in ahead of Shutdown. It is not a deadlock, since the loop always drains eventually, but the behaviour is worse than before. A narrower fix is an RWMutex where Commit takes RLock and Shutdown takes Lock. Alternatively Shutdown could close b.closed first, and Commit could select on b.closed, b.in and ctx.Done() when sending.
Fix: —

### Item 2
Location: lib/batcher/batcher.go:267
Claim: Admission is not cancellable. Commit takes a plain sync.Mutex and does a bare channel send, so it ignores ctx and ignores b.closed while blocked. A Commit stuck on a full channel or on the mutex cannot be aborted.
Consequence: A caller cancels its ctx while another Commit is stuck sending on a full b.in. The caller sits in admitMu.Lock() until the whole queue drains, ignoring cancellation. Previously only the channel send blocked. Now every Commit is serialized behind whichever one is blocked. Selecting on ctx.Done() and b.closed during the send would remove this. That option would also allow a design that doesn't hold the lock across a blocking send.
Fix: —

### Item 3
Location: lib/batcher/batcher.go:274
Claim: fs.Debugf runs while admitMu is held. It calls b.f.String() and does logging I/O inside the critical section that Shutdown and every other Commit contend on.
Consequence: A slow or blocking logger, or a String() method on the Fs that takes locks, stalls all Commits and Shutdown. The new test relies on exactly this by blocking inside String() while holding the lock. Move the Debugf before the Lock, or after the closed check but outside the lock, if it is not needed inside. Alternatively make the lock scope tighter.
Fix: —

### Item 4
Location: lib/batcher/batcher_test.go:283
Claim: The test is timing-based and always burns 100ms. With the fix, b.closed cannot close while Commit holds admitMu, so the `case <-b.closed` branch never fires and the select always waits the full 100ms. This is a fixed sleep per subtest, and it only proves Shutdown is contending, not that it has reached admitMu.Lock().
Consequence: On a slow or loaded CI machine Shutdown may not have reached the lock within 100ms, and release may happen first. The test then passes vacuously and no longer exercises the race, although the fix is still correct. There is also no synchronisation showing that Shutdown is actually blocked on admitMu.
Fix: —

### Item 5
Location: lib/batcher/batcher_test.go:262
Claim: The test mutates the global fs config (`ci.LogLevel`) from the test goroutine while the Commit goroutine may still be reading it. The restore/reset dance is also confusing: LogLevel is set to Debug, then reset early, then reset again in a defer.
Consequence: `ci.LogLevel = oldLogLevel` at line 279 writes the shared config while the Commit goroutine is blocked inside Debugf. If the logger re-reads the level after String() returns, this is a data race under -race and could make the run flaky. It also breaks if tests are ever run with t.Parallel. The write-then-restore is fragile, and the early reset is easy to break when the test is edited.
Fix: —

### Item 6
Location: lib/batcher/batcher_test.go:239
Claim: Only the case where Commit is already inside the lock when Shutdown starts is tested. No test covers a Commit arriving after Shutdown has closed admission, and none covers many concurrent Commits racing Shutdown.
Consequence: The regression coverage does not check that a Commit issued after Shutdown returns the 'batcher is shutting down' error and does not deadlock. It also does not check that the lock is released on that early-return path, which is a future refactor hazard. A stress test with several concurrent Commits and one Shutdown, as ncw's reproduction did, would catch reordering regressions that this single deterministic interleaving cannot.
Fix: —

### Item 7
Location: lib/batcher/batcher.go:252
Claim: Shutdown's `b.in <- quit` also runs under admitMu and can block when the channel is full. It has no timeout, and the manual Lock/Unlock pairs across several return paths are not exception-safe (no defer).
Consequence: If the commit loop is stuck in a hung backend commit(), Shutdown holds admitMu while blocked on the full-channel send. Every subsequent Commit then blocks on the mutex instead of getting the fast 'shutting down' error, which the issue said was the intended behaviour. A panic between Lock and Unlock would also leave the mutex held. Using `defer b.admitMu.Unlock()` in a small helper would be safer.
Fix: —
