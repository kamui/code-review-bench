# Review blind-bfb3bc

### Item 1
Location: packages/server/src/core/internals/utils.ts:11-30
Claim: Keep Overwrite a single object type when TType is any. A router built on `initTRPC.context<any>()` adds context in a middleware, for example `t.procedure.use((opts) => opts.next({ ctx: { extra: 1 } })).query(({ ctx }) => ctx.foo.bar)`.
Consequence: `any` distributes into both branches of the new `TType extends object` test, so ctx becomes a union with the non-indexable `{ extra: number }` and `ctx.foo` fails with TS2339, where the merge-base compiled cleanly.
Fix: In `Overwrite`, test for `any` first (for example `0 extends 1 & TType`) and keep the key-by-key mapped type for that case, then add an `initTRPC.context<any>()` middleware case to `packages/tests/server/regression/issue-5020-inference-middleware.test.ts`.

### Item 2
Location: packages/server/src/core/internals/utils.ts:25-30
Claim: Drop the unreachable `TType` fallback in Overwrite. `TWith extends any` on line 26 is true for every type, and for `never` the distributive conditional yields `never` before reaching the `: TType` arm, so `Overwrite<string, never>` is `never`, not `string`.
Consequence: The doc comment says a non-object `TType` is overwritten "unless TWith is never", which suggests `Overwrite<X, never>` keeps `X`, and the dead arm reinforces that misreading.
Fix: Collapse the non-object arm to `TWith` and reword the doc comment to say that a `never` `TWith` yields `never`.

### Item 3
Location: (no file)
Claim: The new test declares `voidWithMiddleware` but never asserts on it, leaves two `// ^?` editor markers, and covers only a string input, not number, array, union or object inputs.
Consequence: `packages/tests/server/regression/issue-5020-inference-middleware.test.ts:11-16`, `:30-33`.
Fix: —
