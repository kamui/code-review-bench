# Review blind-e3f3d2

### Item 1
Location: (no file)
Claim: I'll start by gathering the diff under review.
Consequence: —
Fix: —
