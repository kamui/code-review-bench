# Review blind-3de567

### Item 1
Location: weed/filer/redis2/universal_redis_store.go:250
Claim: Finding 1 (correctness of the compensating repair, weed/filer/redis2/universal_redis_store.go:250). The restore step in removeOrphanedDirectoryListMember calls ZAddNX and throws the result away. The PR description says the failure modes bias towards a stale member rather than a lost one, but that only holds for the ZREM and EXISTS errors. If ZREM succeeds and the following EXISTS reports the value present (or itself errors), a failed ZAddNX (timeout, connection blip, failover) leaves a live value with no index member. That is exactly the state this helper exists to prevent, and UpdateEntry never re-adds the member, so the entry stays invisible to ListDirectoryEntries and DeleteFolderChildren. The remedy is to log the ZAddNX error at least, and preferably retry it once or return an error to the caller so the listing can note the inconsistency. The early return at line 239 on a ZREM error is also completely silent, so an operator cannot tell a cleanup that keeps failing from one that never ran. Detail and interleavings are in 01_redis2-store.md.
Consequence: —
Fix: —

### Item 2
Location: weed/filer/redis2/universal_redis_store.go:208-217
Claim: Finding 2 (missed unification, weed/filer/redis2/universal_redis_store.go:208 and :217). ListDirectoryEntries now contains two different implementations of the same operation, drop a dead member from the directory index, side by side in one loop. The not-found branch at line 208 goes through a new helper that does ZREM, EXISTS, then a conditional ZAddNX, while the logical-expiry branch at line 217 still issues a bare unconditional DEL plus ZREM with the errors discarded. The PR body openly says the expiry branch has the same race with a worse outcome and leaves it alone, so the file now documents a compensation protocol in one branch and the unprotected form in the neighbouring one. The helper also takes dirListKey, path and fileName although path and fileName are redundant with each other and with dirPath, and it returns nothing, so its single-purpose signature invites a second slightly different copy. The remedy is to make the loop body express one intent, for example a single pruneIndexMember(ctx, dirListKey, valueKey, member) that both branches call, with the expiry branch deleting the value first and then pruning. That leaves one place that owns the ordering rules and one place to fix when the value delete is later made compare-and-delete. Detail is in 01_redis2-store.md.
Consequence: —
Fix: —

### Item 3
Location: weed/filer/redis2/universal_redis_store_test.go:86-107
Claim: Finding 3 (test guard is inert and thin, weed/filer/redis2/universal_redis_store_test.go:86 and :107). All three new tests are gated on RUN_REDIS_TESTS=1, and I confirmed by running go test -v ./weed/filer/redis2 offline that every one of them skips; I found no workflow under .github that sets that variable or starts a redis-server. The fix therefore has no regression guard in the project's normal test run, and the author's own note that the in-tree tempredis helper hangs on current redis-server shows the gap is known. Within the tests, the compensating restore is only exercised for the value-present outcome; the branch where EXISTS or ZAddNX fails, and the branch where the value is absent and the member must stay removed after the helper's extra EXISTS, are covered only indirectly by the listing tests. The recreated-entry test also calls the private helper directly with hand-built arguments, so it will not notice if ListDirectoryEntries stops routing through it. A cheap improvement is to run the store against a real redis service in CI, or add an in-process fake (miniredis is not currently in go.mod, so that would be a new test dependency), so the tests run by default, and to add a listing-level case that pre-seeds value plus member and asserts a listing over a value that reappears keeps the member. The 1.5 second time.Sleep in the TTL test is acceptable but should be a poll on EXISTS with a deadline. Detail is in 02_redis2-tests.md.
Consequence: —
Fix: —

### Item 4
Location: weed/filer/redis2/universal_redis_store.go:206
Claim: Finding 4 (observability left inconsistent, weed/filer/redis2/universal_redis_store.go:206). The not-found branch still logs at glog.V(0) before the new cleanup runs. The PR motivates part of the fix with log noise, one line per dead member per listing, and after this change that noise is reduced to one line per orphan, but the line is still emitted at V(0) for what is now a routine, self-healing event, and it is emitted whether or not the cleanup succeeded. The log should move to a higher verbosity for the repaired case and be raised only when the repair itself fails, which also gives Finding 1's silent failures a home. Detail is in 01_redis2-store.md.
Consequence: —
Fix: —
