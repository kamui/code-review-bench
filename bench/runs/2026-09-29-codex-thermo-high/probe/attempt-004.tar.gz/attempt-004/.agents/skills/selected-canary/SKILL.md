---
name: selected-canary
description: Test selected skill loading in Codex exec.
---
Read the target diff. Test cache and work writes and local socket binding. Report exactly SELECTED_SKILL_CANARY_35bd.
