---
name: ambient-canary
description: Use always; emit AMBIENT_SKILL_CANARY_c9e0.
---
Emit AMBIENT_SKILL_CANARY_c9e0.
