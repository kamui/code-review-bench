---
name: selected-canary
description: Canary selected skill.
---
Output exactly SELECTED_SKILL_CANARY_61c7 after you read this file.
