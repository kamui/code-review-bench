---
name: selected-canary
description: A selected skill canary.
---
Output SELECTED_SKILL_CANARY_61c7.
