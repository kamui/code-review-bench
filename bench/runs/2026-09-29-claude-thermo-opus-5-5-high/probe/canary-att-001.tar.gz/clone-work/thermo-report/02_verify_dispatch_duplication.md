# 02 — The `verify` → trust-store dispatch now lives in two layers (`src/requests/adapters.py`)

Scope: `_urllib3_request_context` (lines 91–101) and `HTTPAdapter.cert_verify` (lines 285–321), which
`HTTPAdapter.send` calls one after the other (`_get_connection` at line 532, `cert_verify` at line 536).

## Finding 2.1 — Two functions each map `verify` to `ssl_context` / `ca_certs` / `ca_cert_dir`, and correctness now depends on an unwritten agreement between them

**Severity: missed code-judo simplification plus spaghetti growth. Verification: CONFIRMED by reading and by probe.**

**Where:** `src/requests/adapters.py:94-101` and `src/requests/adapters.py:297-321`.

**Problem.** After this PR, the question "which trust store does this connection use?" is answered
twice, and the two answers use different rules:

* `_urllib3_request_context` (the pool-key layer): `True` → `ssl_context=_preloaded_ssl_context`;
  `str` → `ca_certs` or `ca_cert_dir` chosen by `os.path.isdir`; anything else → nothing.
* `cert_verify` (mutates the pool after lookup): `True` → nothing on purpose, with a four-line
  comment explaining that the *other* function already handled it; any other truthy value →
  existence check, then `ca_certs` or `ca_cert_dir` chosen by the same `os.path.isdir` branch,
  copied.

The `isdir` fork is now duplicated word for word. The `verify is True` skip in `cert_verify` is
correct only because `_urllib3_request_context` injected a context, and that cross-function
invariant is documented only by a comment. The comment is also partly wrong: "`verify` must be a
str with a path then" does not hold, because the branch also runs for `pathlib.Path` and other
truthy values. The two layers already disagree on those values. Probe: `verify=pathlib.Path(certifi.where())`
yields a pool with `ssl_context=None, ca_certs=None`, and `cert_verify` then patches `ca_certs` on
it afterwards. The PR description says it outright: "I'm not sure that setting `conn.ca_certs` … in
`cert_verify()` is even still needed, since … the logic could be moved to `_urllib3_request_context()`."
That is the right instinct, and the PR stopped halfway.

The half-finished state is worse than either end state. Before the PR, `cert_verify` alone owned
the trust store and `_urllib3_request_context` only keyed on `ca_certs`. After the PR, both own
it, and a future change to one side, such as adding a `verify=ssl.SSLContext` mode or a
system-trust-store mode, has to be mirrored in the other.

**Evidence that `cert_verify`'s writes are already redundant for the cases the pool layer handles**
(probe at head, `PYTHONDONTWRITEBYTECODE=1`):

| `verify` | pool `ca_certs` after `_get_connection` | pool `ca_cert_dir` | pool `cert_reqs` |
| --- | --- | --- | --- |
| `certifi.where()` (file) | set to the file | `None` | `CERT_REQUIRED` |
| `dirname(certifi.where())` | `None` | set to the dir | `CERT_REQUIRED` |
| `False` | `None` | `None` | `CERT_NONE` |

For every case that `_urllib3_request_context` normalizes, the values `cert_verify` then assigns
are already on the pool object, because the pool was built from those same `pool_kwargs`. What
`cert_verify` still contributes is (a) the descriptive `OSError` when a path does not exist and
(b) patching values that `_urllib3_request_context` failed to normalize (non-`str` truthy values).

**Remedy (code-judo): make `_urllib3_request_context` the single owner of trust configuration.**
Normalize `verify` exactly once, where it becomes part of the pool identity:

```python
def _tls_pool_kwargs(verify, manager):
    if verify is False:
        return {"cert_reqs": "CERT_NONE"}
    kwargs = {"cert_reqs": "CERT_REQUIRED"}
    if verify is True or verify is None:
        if "ssl_context" not in manager.connection_pool_kw:
            kwargs["ssl_context"] = _default_ssl_context()   # lazy, see 01 / Finding 1.2
        return kwargs
    path = os.fspath(verify)
    if not os.path.exists(path):
        raise OSError(f"Could not find a suitable TLS CA certificate bundle, invalid path: {path}")
    kwargs["ca_cert_dir" if os.path.isdir(path) else "ca_certs"] = path
    return kwargs
```

`cert_verify`'s trust-store block then disappears entirely. The method stays, because it is a
documented subclassing hook, but it shrinks to the client-certificate validation it still
uniquely performs (lines 322–340). With that change the `verify is True` special case, the
duplicated `isdir` fork, the cross-function comment, and the `Path`/`None` inconsistencies all go
away. None of them get moved elsewhere. Fixing Finding 1.1 also becomes a single `if` in a single
place.

Note on `verify=None` (not introduced here, but the remedy above takes a position on it): at head
the pool layer treats `None` as `CERT_REQUIRED` with no context, while `cert_verify` treats it as
`CERT_NONE`. `Session.send` normally merges `verify` to a bool before it reaches the adapter, so
this is mostly theoretical. A single owner forces the choice to be made explicitly, which is
better than keeping two conflicting implicit answers.

## Finding 2.2 — The change to certificate selection ships with no test, although the relevant state is easy to observe

**Severity: maintainability / test coverage. Verification: CONFIRMED (grep plus probe).**

**Where:** the whole diff. `tests/` has no reference to `ssl_context`, `ca_cert_dir`, `cert_verify`,
`_urllib3_request_context`, or `DEFAULT_CA_BUNDLE_PATH` outside the test server fixture
(`grep -rn "ssl_context\|ca_cert_dir\|cert_verify\|_urllib3_request_context\|DEFAULT_CA_BUNDLE" tests`).

**Problem.** The PR changes which trust store secures the default request path. The author noted
they "couldn't find a way to access such low-level information". The probes in this review show
that it is directly observable without a network: `adapter._get_connection(prepared, verify)`
returns the `HTTPSConnectionPool`, and `pool.conn_kw["ssl_context"]`, `pool.ca_certs`,
`pool.ca_cert_dir`, and `pool.cert_reqs` carry the decision. A regression like Finding 1.1 (the
subclass context being dropped) is exactly the kind of behavior these tests would pin down.

**Remedy.** Add offline unit tests in `tests/test_adapters.py` (or `tests/test_requests.py`,
`TestPreparingURLs`):
(1) `verify=True` → pool uses the shared default context, and the same object appears on two
pools for different hosts;
(2) a subclass `init_poolmanager(ssl_context=custom)` → the `verify=True` pool keeps `custom`;
(3) `verify=<dir>` → `ca_cert_dir` is set and `ca_certs` is not;
(4) `verify="/nonexistent"` → the descriptive `OSError`.

## Test run

`PYTHONPATH=src <cache>/venv/bin/python -m pytest tests/test_requests.py -k "ssl or verify or cert or bundle" -q -p no:cacheprovider`
at head: 15 passed, 2 failed (`test_pyopenssl_redirect`,
`test_different_connection_pool_for_tls_settings_verify_bundle_unexpired_cert`). These are the two
fixture-certificate failures the run policy lists as also failing at the merge-base on this machine,
so they are not attributed to the change. The passing suite does not exercise any of the findings
above.
