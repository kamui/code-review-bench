# 01 — Who owns the default TLS context? (`src/requests/adapters.py`)

Scope: the new module-level `_preloaded_ssl_context` (lines 75–78) and the `verify is True` branch in
`_urllib3_request_context` (lines 94–95), as they interact with `HTTPAdapter.init_poolmanager`,
`HTTPAdapter.proxy_manager_for`, and urllib3's `PoolManager` keyword merging.

Review range: `8dd3b26bf59808de24fd654699f592abf6de581e..4089f3dc65f783beaa53cc032958ab625440d0ac`
(`git diff main...review-head`, 1 file, +28/−18). `adapters.py` goes from 606 to 616 lines, so the
1k-line rule does not apply.

## Finding 1.1 — A per-request `ssl_context` override now silently discards any adapter-level `ssl_context` whenever `verify=True`

**Severity: structural regression, presumptive blocker. Verification: CONFIRMED by execution.**

**Where:** `src/requests/adapters.py:94-95` (`elif verify is True: pool_kwargs["ssl_context"] = _preloaded_ssl_context`).

**Problem.** Before this PR, `_urllib3_request_context` only put per-request *settings* into
`pool_kwargs` (`cert_reqs`, `ca_certs`, client cert). The *TLS context* belonged to the adapter.
Subclasses could supply it in the documented subclassing hook
(`init_poolmanager(..., ssl_context=ctx)`, and in the same way through `proxy_manager_for(**proxy_kwargs)`).
urllib3's `PoolManager.connection_from_host(..., pool_kwargs=...)` merges the request's `pool_kwargs`
*over* the manager's `connection_pool_kw`, and the request's values win. By adding an `ssl_context`
at the request layer for the default `verify=True` case, the PR quietly swaps the adapter's
context for the module global. This happens on the most common path in the library, and it raises
no error and no warning. The subclass's context still takes effect for `verify=False`. So the same
adapter now uses its own context or someone else's depending on the verify flag, and nothing in the
code makes that split visible.

This is an ownership bug before it is a behavior bug. The request layer has taken over a concept
(the TLS context) that the adapter layer already owned, and nothing reconciles the two.

**Evidence (probe run at head and at the merge-base, outside the clone, in the attempt tmp dir):**

```python
custom = create_urllib3_context()
class A(HTTPAdapter):
    def init_poolmanager(self, *a, **kw):
        kw["ssl_context"] = custom
        super().init_poolmanager(*a, **kw)
a = A(); req = requests.Request("GET", "https://example.com").prepare()
conn = a._get_connection(req, True)
conn.conn_kw.get("ssl_context") is custom
```

| Tree | `verify=True` pool uses subclass context? | `verify=False` pool uses subclass context? |
| --- | --- | --- |
| merge-base `8dd3b26b` | **True** | True |
| head `4089f3dc` | **False** (it is `_preloaded_ssl_context`) | True |

Commands: `PYTHONPATH=clone/src <venv>/python tmp/probe.py` and the same against an exported copy of
`main` (`git archive main src | tar -x -C tmp/base`).

The practical impact goes past "custom context ignored". People write this subclass to pin
ciphers or minimum TLS versions, to set `check_hostname`/SNI, to load a corporate trust store, or
to plug in `truststore`/OS stores. All of that is dropped silently on the default path, and the
connection is verified against certifi only.

**Remedy (code-judo).** Keep the default context inside the layer that already owns contexts, and
stop letting it override unconditionally per request. The smallest change that fits the
architecture treats the preloaded context as a *fallback default*, not a request-level override.
The `verify is True` branch looks at the manager the request will actually use, and supplies the
default only when that manager has no context of its own:

```python
def _get_connection(self, request, verify, proxies=None, cert=None):
    manager = self.proxy_manager_for(proxy) if proxy else self.poolmanager
    host_params, pool_kwargs = _urllib3_request_context(request, verify, cert, manager)
    ...

# in _urllib3_request_context
    elif verify is True and "ssl_context" not in manager.connection_pool_kw:
        pool_kwargs["ssl_context"] = _default_ssl_context()
```

This way the default is used only when the adapter never configured a context. If a subclass did
configure one, `cert_verify` has to keep its old job of pointing that context at the default
bundle, so that behavior matches the merge-base (see detail file 02 for making that single-owner
instead of split). Add a regression test that asserts
`A()._get_connection(req, True).conn_kw["ssl_context"] is custom`.

## Finding 1.2 — Import-time TLS work: `import requests` now builds a context and reads the CA bundle, and fails outright without `ssl`

**Severity: boundary / lifecycle regression. Verification: CONFIRMED by execution (ssl-less import); the frozen-path behavior was CONFIRMED by probe.**

**Where:** `src/requests/adapters.py:75-78`.

**Problem.** The PR moves one-time TLS setup to module import:
`create_urllib3_context()`, then `extract_zipped_paths(DEFAULT_CA_BUNDLE_PATH)`, which extracts the
bundle to a temp dir when requests runs from a zip or pyinstaller archive, then
`load_verify_locations(...)`. The PR body names `load_verify_locations` as the slow call, and this
change runs it on every `import requests`. That includes processes that only make plain-HTTP calls,
processes that only use `verify=False` or a custom bundle, and CLIs that import requests but never
use it. A module global that does I/O and native-library setup at import is the "magic" hidden
state the approval bar warns against. It moves failures away from the call that caused them:

* **No `ssl` module → `import requests` fails.** With `sys.modules['ssl'] = None`, the head raises
  `TypeError: Can't create an SSLContext object without an ssl module` at import. The merge-base
  imports cleanly. Before this PR, Python builds without `ssl` could still use requests for
  `http://` URLs, and now they cannot import it at all.
* **Missing or broken bundle → the error moves to import time and loses its message.** The
  merge-base raised `OSError("Could not find a suitable TLS CA certificate bundle, invalid path: …")`
  at request time from `cert_verify`. The head deletes that check for `verify=True` (lines 304–317
  now only run for non-`True` values). A bad bundle now shows up as a raw `FileNotFoundError` or
  `ssl.SSLError` from inside `import requests`.
* **`DEFAULT_CA_BUNDLE_PATH` is snapshotted.** The value is read once at import. Probe: after
  `requests.adapters.DEFAULT_CA_BUNDLE_PATH = "/nonexistent"`, the merge-base's `cert_verify(conn, url, True, None)`
  raises the descriptive `OSError`. The head sets nothing (`ca_certs=None`) and keeps verifying
  against the import-time bundle. Code that patches this module attribute, which some packaging
  and test setups do, silently stops working.

**Remedy.** Replace the eager global with a lazily built, cached accessor, so the cost and the
failure modes show up on the first verified HTTPS request that needs them and nowhere else:

```python
@functools.lru_cache(maxsize=None)
def _default_ssl_context():
    ctx = create_urllib3_context()
    ctx.load_verify_locations(extract_zipped_paths(DEFAULT_CA_BUNDLE_PATH))
    return ctx
```

(Or key the cache on the resolved bundle path if honoring a patched `DEFAULT_CA_BUNDLE_PATH` matters.)
Keep the `os.path.exists` check and its descriptive `OSError` inside this accessor so that the
merge-base error contract survives. This does not weaken the performance win: the context is still
built once per process, and pools created later still share it.
