# Thermo-nuclear code quality review — `psf/requests#6667`

"Avoid reloading root certificates to improve concurrent performance"
Range `8dd3b26bf59808de24fd654699f592abf6de581e..4089f3dc65f783beaa53cc032958ab625440d0ac`, one file
(`src/requests/adapters.py`, +28/−18, 606 → 616 lines).

## Verdict

**Do not approve as written.** The goal is sound: build the default CA context once and share it,
instead of calling `load_verify_locations` on every connection. The context is shared correctly,
and the performance motivation is well argued. The implementation, though, puts the new concept in
the wrong layer and at the wrong time. It becomes a per-request override that silently beats
adapter-configured TLS contexts, and it is built eagerly at import. It also leaves the
`verify`-to-trust-store mapping split across two functions that now rely on an unwritten invariant
between them. There is a clear code-judo move that fixes all three: one lazily built default
context, supplied only as a fallback, from one function that owns trust configuration. That change
would delete the special case in `cert_verify` rather than rearrange it.

Every finding below was checked by running a probe against the head and against an exported copy
of the merge-base. The clone was not modified. The focused ssl/verify test selection passes except
for the two fixture-certificate failures that the run policy lists as pre-existing, and it does not
cover any of these findings.

## Findings

### 1. `verify=True` now silently discards any `ssl_context` configured on the adapter (structural regression, blocker)

In `src/requests/adapters.py:94-95`, `_urllib3_request_context` now adds
`pool_kwargs["ssl_context"] = _preloaded_ssl_context` for `verify=True`. urllib3 merges request
`pool_kwargs` over the `PoolManager`'s `connection_pool_kw`, and the request values win. So a
subclass that follows the documented pattern of passing `ssl_context=` through `init_poolmanager`
(or `proxy_manager_for`) loses its context on the default path, without any error. A probe showed
that the merge-base pool keeps the subclass's context for `verify=True`, while the head pool
replaces it with the module global. `verify=False` still keeps it. Pinned ciphers, minimum TLS
versions, corporate trust stores, and OS-trust-store integrations are therefore dropped on the most
common code path. The root cause is that the request layer has taken over a concept the adapter
layer already owned. The remedy is to treat the shared context as a fallback default. Supply it
only when the manager the request will use has no `ssl_context` of its own, and in that case keep
pointing the subclass's context at the default bundle as before. Pin this with a regression test.
Full evidence and a worked proposal are in `01_tls_context_ownership.md` (Finding 1.1).

### 2. TLS setup moved to import time: `import requests` now does I/O, fails without `ssl`, and snapshots the bundle path (boundary regression)

`src/requests/adapters.py:75-78` creates a urllib3 context, extracts the certifi bundle out of
any zip archive, and calls `load_verify_locations` during `import requests`. That is the same slow
call the PR sets out to avoid, and now every importer pays for it, including code that never makes
a verified HTTPS request. A probe with `sys.modules['ssl'] = None` showed that the head fails at
import with `TypeError: Can't create an SSLContext object without an ssl module`, while the
merge-base imports cleanly. The PR also removes `cert_verify`'s descriptive
"Could not find a suitable TLS CA certificate bundle" `OSError` for `verify=True`, so a missing
bundle now surfaces as a raw error from inside the import. Changes to
`requests.adapters.DEFAULT_CA_BUNDLE_PATH` after import are also silently ignored. The probe showed
the merge-base raising the descriptive error for a patched nonexistent path, while the head
verifies against the import-time bundle. The remedy is a lazily built, cached accessor such as
`_default_ssl_context()`, which keeps the existence check and its error message inside. The context
is still built once per process, so the performance win survives. Details are in
`01_tls_context_ownership.md` (Finding 1.2).

### 3. The `verify` → trust-store mapping is duplicated across `_urllib3_request_context` and `cert_verify`, joined by a comment-only invariant (missed code-judo, spaghetti growth)

After this PR, `_urllib3_request_context` (`src/requests/adapters.py:91-101`) and `cert_verify`
(`src/requests/adapters.py:297-321`) each decide between `ssl_context`, `ca_certs`, and
`ca_cert_dir`. The `os.path.isdir` fork is copied word for word. `cert_verify` gains a special case
(`if verify is not True`) that is correct only because the other function injected a context,
which a four-line comment explains. The comment's claim that `verify` "must be a str" is also
false: for a `pathlib.Path`, the pool layer sets nothing and `cert_verify` patches `ca_certs` on
the pool afterwards. A probe confirmed that for file, directory, and `False` values,
`cert_verify`'s assignments are already present on the pool, because the pool was built from the
same `pool_kwargs`. The author's own PR description suggests moving this logic into
`_urllib3_request_context`. That is the right move, and the PR stopped halfway, leaving a
half-migrated state that is worse than either end. The remedy is to normalize `verify` once, in a
single helper that owns `cert_reqs`, the fallback context, the existence check, and the
file-vs-directory choice. `cert_verify` then shrinks to client-certificate validation. The special
case, the duplicate fork, the explanatory comment, and the `Path`/`None` inconsistencies all
disappear. A worked `_tls_pool_kwargs` sketch is in `02_verify_dispatch_duplication.md`
(Finding 2.1).

### 4. The change to certificate selection ships untested, although the state is directly observable offline (test coverage)

Nothing under `tests/` refers to `ssl_context`, `ca_cert_dir`, `cert_verify`, or
`_urllib3_request_context`. The author said they could not reach this state from tests, but
`adapter._get_connection(prepared_request, verify)` returns the pool, and `conn_kw["ssl_context"]`,
`ca_certs`, `ca_cert_dir`, and `cert_reqs` expose the whole decision without any network. Finding
1 is exactly the kind of regression such tests would have caught. Add offline tests for:

- the shared default context on `verify=True`;
- a subclass `ssl_context` surviving `verify=True`;
- a directory bundle mapping to `ca_cert_dir`;
- the descriptive `OSError` for a nonexistent path.

Details are in `02_verify_dispatch_duplication.md` (Finding 2.2).

## Proposed remediation sequence

1. Replace the eager `_preloaded_ssl_context` global with a lazily built, cached
   `_default_ssl_context()` that performs the bundle existence check and raises the existing
   descriptive `OSError` (Finding 2).
2. Collapse the trust-store mapping into one helper, called from `_get_connection`, that has
   access to the target manager. It supplies the default context only when the manager has no
   `ssl_context`, and it chooses `ca_certs` or `ca_cert_dir` once (Findings 1 and 3).
3. Remove the trust-store block from `cert_verify` and keep the method as the documented hook for
   client-certificate validation (Finding 3).
4. Add the four offline pool-inspection tests before merging (Finding 4).

## Detail files

- `01_tls_context_ownership.md`: the context-override regression and the import-time lifecycle
  regression, with probe code, merge-base vs. head results, and remedies.
- `02_verify_dispatch_duplication.md`: the duplicated dispatch, the redundancy evidence table,
  the worked single-owner refactor, the test-coverage gap, and the test run record.
