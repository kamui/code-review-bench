# Detail report 01: `src/requests/adapters.py` TLS context preloading

Scope: the single changed file, range `8dd3b26b..4089f3dc` (`git diff main...review-head`). Reviewed by direct reading of the diff, the head version of `adapters.py`, `utils.extract_zipped_paths`, and the installed urllib3 (`connection.py`, `util/ssl_.py`). No tests were run; verification below is by code reading only.

## Finding 1: a mutable process-global SSLContext is shared by every `verify=True` connection, and urllib3 will mutate it with client certificates (adapters.py:75-78, 94-95)

Evidence. The PR builds `_preloaded_ssl_context` at module scope and injects it as `pool_kwargs["ssl_context"]` for every request with `verify is True`. In the installed urllib3, `util/ssl_.py:ssl_wrap_socket` (around lines 430-433) runs `context.load_cert_chain(certfile, keyfile)` on whatever context it is handed whenever `cert_file` is set. `_urllib3_request_context` still forwards `cert_file`/`key_file` into the same `pool_kwargs` (adapters.py:100-106 at head). So `requests.get(url, cert=("a.pem","a.key"))` with default verification now calls `load_cert_chain` on the one process-wide context. Every later `verify=True` connection in the process, including for different hosts, sessions and adapters, then presents that client certificate during handshake, and a later `cert=` call adds or replaces the chain again. Also, `connection.py:_ssl_wrap_socket_and_match_hostname` (line ~1042) writes `context.verify_mode` and possibly `check_hostname` on the shared object each connect.

Status: CONFIRMED by reading urllib3 source; not reproduced by a test run (no network).

Why it is a design problem and not just a bug. The change turned a per-pool object into hidden global mutable state, and the reviewers' own discussion ("modifying it in a way we don't want to be supporting") only addressed user mutation via the public name, not mutation by the library's own dependency. Renaming to a leading underscore does not fix that. The state model is wrong: what is cacheable is the immutable part (loaded root CAs), and client-cert loading is per-request configuration.

Code-judo proposal. Do not share a context that any code path may configure. Either (a) only inject the shared context when `client_cert is None`, and let the `cert=` case fall back to a per-pool context; or better (b) keep the expensive part shared but hand each pool its own cheap context, e.g. build the context lazily per adapter (`functools.lru_cache`d factory keyed on nothing, or held on the `HTTPAdapter` instance) and never pass client certs into it. Option (b) also answers Nate Prewitt's per-adapter question. A cheaper structural alternative is to fold the default into `pool_kwargs["ca_certs"]` plus a urllib3-level cache, but that depends on urllib3 changes.

## Finding 2: import-time side effect that does I/O, can raise at `import requests`, and removes the friendly lazy error (adapters.py:75-78, cert_verify 297-317)

Evidence. The module-level statements call `create_urllib3_context()` and `load_verify_locations(extract_zipped_paths(DEFAULT_CA_BUNDLE_PATH))` when `requests.adapters` is imported. Before the PR, a missing or unreadable bundle produced `OSError("Could not find a suitable TLS CA certificate bundle, invalid path: ...")` at request time, and only for `verify=True` callers. The diff deletes that default-path existence check from `cert_verify`. Now a missing or corrupt bundle (stripped-down PyInstaller/zipapp builds, distro packages that remove certifi's `cacert.pem`, unreadable temp dir when extracting from a zip) raises a raw `FileNotFoundError` or `ssl.SSLError` from `import requests`, even for programs that only use `verify=False`, or never make HTTPS calls. It also adds the cost the PR is trying to avoid (roughly hundreds of ms per the PR's own profile) to every import, including CLI tools and pip-vendored uses of requests. `extract_zipped_paths` also writes into `tempfile.gettempdir()` at import.

Status: CONFIRMED by reading (module-level code and deleted check are in the diff).

Code-judo proposal. Make the context lazy: a small `_get_default_ssl_context()` with `functools.lru_cache(maxsize=None)` (or a module-level lock plus cache) called from `_urllib3_request_context` only when `verify is True`. That keeps the exact performance gain, restores request-time failure with the original error message, and removes import-time cost. It also gives one natural place to attach the friendly `OSError` wrapper.

## Finding 3: path classification is now implemented twice, and the custom-bundle path still pays the redundant `load_verify_locations` the PR set out to remove (adapters.py:96-100 vs 304-317)

Evidence. `_urllib3_request_context` now decides `ca_certs` versus `ca_cert_dir` via `os.path.isdir(verify)`. `cert_verify` independently repeats the same `os.path.isdir` split and assigns `conn.ca_certs` / `conn.ca_cert_dir`. For `verify=<path>` the pool is created with `ca_certs` (one load at pool creation, cached per pool) and each connection then also loads them via `conn.ca_certs` on the pool (urllib3 `ssl_wrap_socket` loads whenever `ca_certs or ca_cert_dir`), so the same bundle is parsed on every new connection: the exact slowdown of the PR body remains for anyone with `REQUESTS_CA_BUNDLE` or `verify="/path"`, which is a very common corporate configuration. The author flags this in the PR body but leaves it.

Status: CONFIRMED (duplication visible in diff; per-connection load derived from urllib3 code read in `util/ssl_.py:412-417`).

Code-judo proposal. Make `_urllib3_request_context` the single owner of TLS trust configuration. For `verify=str`, build (and cache by path, ideally with mtime or via `lru_cache`) a context with that bundle loaded and pass it as `ssl_context`, exactly like the default case, so "verify" is always "a cached context" and `cert_verify` collapses to setting `cert_reqs`, the existence check, and the `cert` handling. That deletes `conn.ca_certs`/`conn.ca_cert_dir` assignment, the second `isdir` branch, and the special-cased `verify is True` branches in both functions. If the API of `cert_verify` must remain for subclasses, keep only the validation.

## Finding 4: `cert_verify` became a half-contract with an implicit precondition (adapters.py:297-317)

Evidence. `cert_verify` is documented as usable when subclassing. The new code assumes that for `verify is True` the connection was created with the preloaded context (comment: "the connection will be using a context with the default certificates already loaded"). That holds only for connections obtained through `_get_connection`. The legacy public `get_connection(url, proxies)` (adapters.py ~404 onward) does not call `_urllib3_request_context`, and subclass authors still call `get_connection()` followed by `cert_verify(conn, url, True, cert)`. There, `conn` has no `ssl_context` and now no `ca_certs`, so urllib3 falls back to `load_default_certs()`, i.e. the OS trust store instead of certifi's bundle. That silently changes which CAs are trusted for existing subclasses. `cert_verify` previously guaranteed the certifi bundle regardless of how the pool was built.

Status: PLAUSIBLE. The mechanism (no `ca_certs`, no `ssl_context` leads to `load_default_certs`) is confirmed in `util/ssl_.py:419-421` and `connection.py:1060-1068`. Whether real subclasses do this was not surveyed.

Remedy. Same as Finding 3: if the context is always attached to the pool, correctness no longer depends on the call path. Otherwise document the precondition and cover it with a test.

## Finding 5: extra branching, comment noise, and a lopsided branch shape (adapters.py:91-100, 297-317)

Evidence. `if verify is False / elif verify is True / elif isinstance(verify, str)` is followed by a nested `if not isdir ... else ...`, and `cert_verify` gained a nested `if verify is not True:` with the comment "`verify` must be a str with a path then" and a paragraph-length comment (lines longer than the surrounding 79-88 col style; the final commit only wrapped one line). Negated-`if`-with-`else` (`if not os.path.isdir(verify): ... else:`) reads backwards. `verify is True` now has a different meaning from truthy `verify`, which is an unadvertised distinction (`verify=1` or other truthy non-str values previously reached the default bundle; now `verify=1` falls through `_urllib3_request_context` with no context at all and reaches `cert_verify` as `verify is not True` and `os.path.exists(1)`).

Status: CONFIRMED for the branch shapes; the truthy-non-bool regression (`verify=1`) is derived by reading, not executed.

Remedy. Collapse into a single helper (see Finding 3), test positively (`isdir` first), and normalise `verify` once at the boundary.

## Finding 6: no tests accompany a change to security-relevant trust loading

Evidence. The diff is 1 file, +28/-18, with no test changes; the author says they could not find a way to assert which certs a context has loaded. The behavior that changed (which CAs are trusted for `verify=True`, `ca_cert_dir` handling, and no leakage of `cert=`) is exactly what should be pinned. Two SSL-adjacent tests already fail on this machine at merge-base for fixture reasons, so the suite offers little coverage here.

Status: CONFIRMED (diff manifest).

Remedy. Add tests asserting `poolmanager.connection_from_host(..., pool_kwargs=...)` receives an `ssl_context` whose `get_ca_certs()` / `cert_store_stats()` is non-empty for `verify=True`, and one asserting that a `cert=` request does not alter the shared context (`load_cert_chain` mock not called on it).

## File size

`adapters.py` is 616 lines at head; no 1k-line threshold concern.

## Commands used

- `git diff main...review-head`
- `git show review-head:src/requests/adapters.py` (line ranges)
- `grep`/`sed` on `clone-cache/venv/lib/python3.13/site-packages/urllib3/{connection.py,util/ssl_.py}`
