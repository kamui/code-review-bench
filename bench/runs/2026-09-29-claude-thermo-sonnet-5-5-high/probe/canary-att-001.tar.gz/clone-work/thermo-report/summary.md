# Thermo-nuclear review: psf/requests#6667 "Avoid reloading root certificates to improve concurrent performance"

Range `8dd3b26b..4089f3dc`, one file (`src/requests/adapters.py`, +28/-18). Detail: `01_adapters_tls_context.md`. Reviewed by reading only; no tests were run.

## Verdict

Do not approve as written. The performance goal is right and the core idea (reuse one preloaded SSLContext) is the correct lever, but it is implemented as a module-level mutable global that is created at import time, duplicates the path-classification logic in two functions, and leaves the common custom-bundle case (`verify="/path"` or `REQUESTS_CA_BUNDLE`) paying the same per-connection reload it set out to eliminate. A cleaner reframing exists that deletes branches instead of adding them.

## Findings

**1. A single process-global SSLContext is shared by all `verify=True` traffic, and urllib3 mutates it with client certificates.** In `adapters.py:75-78` the module builds `_preloaded_ssl_context` and `_urllib3_request_context` (`adapters.py:94-95`) hands it to every default-verification pool. In the installed urllib3, `ssl_wrap_socket` calls `context.load_cert_chain(certfile, keyfile)` on the supplied context whenever `cert_file` is set, and `_urllib3_request_context` still forwards `cert=` into the same `pool_kwargs`. A single `requests.get(url, cert=(...))` therefore loads that client certificate into the shared context, and later unrelated `verify=True` requests to other hosts, sessions and adapters present it too. The underscore rename does not address mutation by the library's own dependency. Fix: only share a context that nothing configures, either by not injecting it when a client cert is given, or preferably by holding an immutable-by-convention context per adapter and creating a per-pool context for `cert=`. Confirmed by reading urllib3; not executed. Detail: Finding 1.

**2. The context is built at import time, with I/O and no error handling, and the friendly missing-bundle error was deleted.** `adapters.py:75-78` runs `create_urllib3_context()` and `load_verify_locations(extract_zipped_paths(...))` on `import requests.adapters`, and the default-path existence check with its clear `OSError` message was removed from `cert_verify`. A missing, unreadable or corrupt bundle (stripped PyInstaller builds, distro-patched certifi, unwritable temp dir for zip extraction) now breaks `import requests` even for `verify=False` or non-HTTPS users, and adds the very load cost the PR wants to avoid to every import. Fix: a lazily-built, cached factory (`functools.lru_cache`) called only from the `verify is True` branch, which keeps the speedup, restores request-time failure, and gives one place to wrap the error. Confirmed. Detail: Finding 2.

**3. Trust-path classification is duplicated, and custom bundles still reload on every connection.** `_urllib3_request_context` (`adapters.py:96-100`) and `cert_verify` (`adapters.py:304-317`) both branch on `os.path.isdir`, and both set `ca_certs` or `ca_cert_dir`. Because `cert_verify` still assigns `conn.ca_certs`, urllib3 keeps calling `load_verify_locations` for each new connection when `verify` is a path, so corporate-CA users see no improvement. This is the missed code-judo move: make `_urllib3_request_context` the single owner of trust configuration and give every verified request a cached `ssl_context` (default or per-path, cached), which lets `cert_verify` shrink to setting `cert_reqs`, validating paths and handling `cert`. That deletes the `verify is True` special cases, the second `isdir` split and the `conn.ca_*` assignments. The PR body itself concedes this. Confirmed. Detail: Finding 3.

**4. `cert_verify` now depends on an invisible precondition.** It is documented for subclass use, but for `verify is True` it no longer sets any CA source and relies on the pool having been built through `_get_connection`. Subclasses that still call the legacy `get_connection()` followed by `cert_verify()` end up with neither `ssl_context` nor `ca_certs`, and urllib3 then loads the OS trust store rather than certifi, silently changing trust. Attaching the context to the pool unconditionally (Finding 3's remedy) removes the dependency. Plausible: mechanism confirmed in urllib3, subclass prevalence not surveyed. Detail: Finding 4.

**5. Branch shape and comment noise grew in already busy functions.** The three-way `False / True / str` chain with a negated nested `isdir`, the `if verify is not True:` nesting inside `cert_verify`, the "`verify` must be a str with a path then" comment and the long comment paragraph all add reading cost. `verify is True` now means something different from truthy, so a truthy non-bool such as `verify=1` no longer reaches the default bundle (derived by reading, not executed). Normalise at the boundary and use a positive `isdir` test in one helper. Detail: Finding 5.

**6. No tests for a trust-store change.** The diff has no test changes, though it alters which CAs are loaded and how `ca_cert_dir` is handled. Tests can inspect the `ssl_context` passed in `pool_kwargs` (`cert_store_stats()`), and can assert that a `cert=` request leaves the shared context untouched. Detail: Finding 6.

## Proposed remediation sequence

1. Replace the module-level context with a lazily created, cached factory; keep the default-bundle `OSError` message on failure (Finding 2).
2. Stop sharing a context that can receive `load_cert_chain`: skip injection when `cert` is set, or use per-adapter contexts (Finding 1).
3. Route `verify=str` through the same cached-context mechanism and reduce `cert_verify` to validation plus `cert_reqs` (Findings 3 and 4).
4. Normalise `verify` once and delete the nested branches and comments (Finding 5).
5. Add tests for loaded certs, directory bundles and client-cert isolation (Finding 6).

## Notes on scope

`adapters.py` stays at 616 lines, so there is no file-size concern. Prior discussion on the PR (thread safety of SSLContext, public naming) is acknowledged; thread safety of read-only use is fine, and the issue raised above is about configuration of the shared object, which was not covered there.
