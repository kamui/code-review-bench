#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <linux/landlock.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

static const uint64_t handled = (1ULL << 15) - 1;
static const uint64_t file_rights = (1ULL << 0) | (1ULL << 1) | (1ULL << 2) | (1ULL << 14);
static const uint64_t read_rights = (1ULL << 0) | (1ULL << 2) | (1ULL << 3);
static const uint64_t write_rights = ((1ULL << 15) - 1) & ~((1ULL << 6) | (1ULL << 11));

static void fail(const char *operation) {
    perror(operation);
    exit(125);
}

int main(int argc, char **argv) {
    int abi = syscall(SYS_landlock_create_ruleset, NULL, 0, LANDLOCK_CREATE_RULESET_VERSION);
    if (abi < 3) {
        fprintf(stderr, "fixture Landlock requires ABI 3; observed %d, errno %d\n", abi, errno);
        return 125;
    }
    if (argc == 2 && strcmp(argv[1], "--probe") == 0) {
        printf("{\"kernel_abi\":%d,\"policy_abi\":3,\"handled_access_fs\":%llu}\n", abi,
               (unsigned long long)handled);
        return 0;
    }
    struct landlock_ruleset_attr ruleset = {.handled_access_fs = handled};
    int fd = syscall(SYS_landlock_create_ruleset, &ruleset, sizeof(ruleset), 0);
    if (fd < 0)
        fail("landlock_create_ruleset");
    int i = 1;
    for (; i + 1 < argc && strcmp(argv[i], "--") != 0; i += 2) {
        if (strcmp(argv[i], "--read") != 0 && strcmp(argv[i], "--write") != 0) {
            fprintf(stderr, "expected --read PATH or --write PATH\n");
            return 125;
        }
        int path = open(argv[i + 1], O_PATH | O_CLOEXEC);
        if (path < 0)
            fail(argv[i + 1]);
        struct stat st;
        if (fstat(path, &st) != 0)
            fail("fstat");
        uint64_t rights = strcmp(argv[i], "--write") == 0 ? write_rights : read_rights;
        if (!S_ISDIR(st.st_mode))
            rights &= file_rights;
        struct landlock_path_beneath_attr rule = {.allowed_access = rights, .parent_fd = path};
        if (syscall(SYS_landlock_add_rule, fd, LANDLOCK_RULE_PATH_BENEATH, &rule, 0) != 0)
            fail(argv[i + 1]);
        close(path);
    }
    if (i >= argc || strcmp(argv[i], "--") != 0 || i + 1 >= argc) {
        fprintf(stderr, "expected -- COMMAND [ARGS]\n");
        return 125;
    }
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0)
        fail("PR_SET_NO_NEW_PRIVS");
    if (syscall(SYS_landlock_restrict_self, fd, 0) != 0)
        fail("landlock_restrict_self");
    close(fd);
    execvp(argv[i + 1], argv + i + 1);
    fail("execvp");
}
