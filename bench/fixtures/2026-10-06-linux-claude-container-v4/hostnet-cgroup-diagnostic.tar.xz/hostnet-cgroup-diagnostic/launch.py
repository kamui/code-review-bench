import subprocess,json
from pathlib import Path
p=Path('/tmp/finish36-hostnet-cgroup-fndlvnvm')
r=subprocess.run(["podman","import","/tmp/finish36-v4-gg7r_ib2/evidence/rootfs.tar"],capture_output=True,text=True,timeout=90)
image=r.stdout.strip(); name=p.name
command=["podman","--runtime","/tmp/issue-36-crun-1.30.1/crun","--cgroup-manager","cgroupfs","run","--name",name,"--pull","never","--network","host","--pid","private","--ipc","private","--uts","private","--cgroupns","private","--userns","keep-id","--user","1000:1000","--cap-drop","ALL","--security-opt","no-new-privileges","--read-only","--pids-limit","256","--memory","1g","--cpus","2","--timeout","30",image,"/usr/bin/python3","-c","from pathlib import Path; import json; print(json.dumps({\"cgroup\":Path(\"/proc/self/cgroup\").read_text(),\"mounts\":Path(\"/proc/self/mountinfo\").read_text(),\"files\":[x.name for x in Path(\"/sys/fs/cgroup\").iterdir()]}))"]
try:
 r=subprocess.run(command,capture_output=True,text=True,timeout=45); (p/"result.json").write_text(json.dumps({"command":command,"code":r.returncode,"stdout":r.stdout,"stderr":r.stderr}))
finally:
 for command in (["podman","stop","--time","2",name],["podman","rm",name],["podman","image","rm",image]):
  subprocess.run(command,capture_output=True,text=True,timeout=20)
