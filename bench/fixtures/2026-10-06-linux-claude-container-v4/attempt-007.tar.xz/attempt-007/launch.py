import subprocess
from pathlib import Path
p=Path('/tmp/finish36-v4-gg7r_ib2')
with (p/"controller-stdout.txt").open("w") as o,(p/"controller-stderr.txt").open("w") as e:
 r=subprocess.run(['/usr/bin/python3', '/home/jack/.t3/worktrees/code-review-bench/t3code-5c6bbc2c/bench/tools/claude_container_probe_v4.py', 'run', '--output', '/tmp/finish36-v4-gg7r_ib2/evidence', '--claude', '/tmp/issue-36-fixture-v3-015/rootfs/usr/bin/claude', '--claude-sha256', 'a186b99e4a9c88366cd49df2f7dad56c61fc306ef0140b19ee64b7c42a8d1348', '--claude-version', '2.1.289', '--oci-runtime', '/tmp/issue-36-crun-1.30.1/crun', '--oci-runtime-sha256', '86d1e6a0e76945975d3aebfab39cbc6a26eea15f1c3fc66b6776d19e5dc346a0'],stdout=o,stderr=e,timeout=1800)
(p/"exit.txt").write_text(str(r.returncode))
